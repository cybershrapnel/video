"""
check.py — hive fetcher + upscale/upload + complete
Server filters via process.php?max_seconds=&accept_audio=&client_version=
Optional identity: worker_id (contact/email) + ncz_address (NanoCheeZe payout)
"""
from __future__ import annotations

import json
import os
import ssl
import subprocess
import sys
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ══════════════════════════════════════════════════════════
# EASY FLAGS — edit these per machine
# ══════════════════════════════════════════════════════════
MAX_SECONDS = 45          # main PC: 45 | short GPU: 5
ACCEPT_AUDIO = True      # main PC: True | short GPU: False

# Must match process.php PROTOCOL_VERSION
CLIENT_VERSION = "2"

# Optional identity (logged on server into the claimed job folder)
# Prefer an email for WORKER_ID so the operator can contact you; any name is fine.
WORKER_ID = "mequavis_swarm"            # e.g. "you@example.com"
NCZ_ADDRESS = "NcUY5tNtyRvCLPJNzMazSaXmYkcg1QXjZC"          # NanoCheeZe coin address for payouts (optional)
# ══════════════════════════════════════════════════════════

if os.environ.get("MAX_SECONDS"):
    MAX_SECONDS = int(os.environ["MAX_SECONDS"])
if os.environ.get("ACCEPT_AUDIO") is not None:
    ACCEPT_AUDIO = os.environ.get("ACCEPT_AUDIO", "").strip().lower() in (
        "1", "true", "yes", "on"
    )
if os.environ.get("CLIENT_VERSION"):
    CLIENT_VERSION = os.environ["CLIENT_VERSION"].strip()
if os.environ.get("WORKER_ID") is not None:
    WORKER_ID = os.environ.get("WORKER_ID", "").strip()
if os.environ.get("NCZ_ADDRESS") is not None:
    NCZ_ADDRESS = os.environ.get("NCZ_ADDRESS", "").strip()

PROCESS_URL = os.environ.get(
    "PROCESS_URL",
    "https://xtdevelopment.net/video-gen/process.php",
)
COMPLETE_URL = os.environ.get("COMPLETE_URL", PROCESS_URL)
UPLOAD_URL = os.environ.get(
    "UPLOAD_URL",
    "https://xtdevelopment.net/video-gen/upload.php",
)

QUEUE_DIR = Path(os.environ.get("QUEUE_DIR", "queue"))
FINAL_OUT = Path(os.environ.get("FINAL_OUT", "output_concat"))
UPSCALED_DIR = FINAL_OUT / "upscaled"

EMPTY_WAIT = int(os.environ.get("EMPTY_WAIT", "30"))
BUSY_WAIT = int(os.environ.get("BUSY_WAIT", "15"))
UPGRADE_WAIT = int(os.environ.get("UPGRADE_WAIT", "120"))
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "600"))
CHUNK_SIZE = int(os.environ.get("UPLOAD_CHUNK_SIZE", str(8 * 1024 * 1024)))
SINGLE_MAX = int(os.environ.get("UPLOAD_SINGLE_MAX", str(100 * 1024 * 1024)))
UPLOAD_FAIL_WAIT = int(os.environ.get("UPLOAD_FAIL_WAIT", "60"))
CHUNK_RETRIES = int(os.environ.get("CHUNK_RETRIES", "555"))
CHUNK_RETRY_WAIT = int(os.environ.get("CHUNK_RETRY_WAIT", "25"))

SSL_CTX = ssl._create_unverified_context()


def ensure_dirs() -> None:
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    FINAL_OUT.mkdir(parents=True, exist_ok=True)
    UPSCALED_DIR.mkdir(parents=True, exist_ok=True)


def which(cmd: str) -> str | None:
    from shutil import which as _which
    return _which(cmd)


def require_ffmpeg() -> str:
    ff = which("ffmpeg")
    if not ff:
        raise RuntimeError("ffmpeg not on PATH")
    return ff


def local_zips() -> list[Path]:
    if not QUEUE_DIR.is_dir():
        return []
    return sorted(
        [p for p in QUEUE_DIR.iterdir() if p.is_file() and p.suffix.lower() == ".zip"],
        key=lambda p: p.stat().st_mtime,
    )


def job_name_from_final(path: Path) -> str:
    stem = path.stem
    low = stem.lower()
    idx = low.find("_final_")
    if idx > 0:
        return stem[:idx]
    return stem


def uploaded_marker(job_name: str) -> Path:
    return UPSCALED_DIR / f".uploaded_{job_name}"


def is_uploaded(job_name: str) -> bool:
    return uploaded_marker(job_name).is_file()


def mark_uploaded(job_name: str) -> None:
    uploaded_marker(job_name).write_text(
        time.strftime("%Y-%m-%d %H:%M:%S") + "\n",
        encoding="utf-8",
    )


def progress_path(job_name: str) -> Path:
    return UPSCALED_DIR / f".upload_progress_{job_name}.json"


def load_progress(job_name: str) -> dict:
    p = progress_path(job_name)
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_progress(job_name: str, data: dict) -> None:
    progress_path(job_name).write_text(json.dumps(data, indent=2), encoding="utf-8")


def clear_progress(job_name: str) -> None:
    p = progress_path(job_name)
    if p.is_file():
        p.unlink()


def list_pending_finals() -> list[tuple[str, Path]]:
    if not FINAL_OUT.is_dir():
        return []
    by_job: dict[str, Path] = {}
    for p in FINAL_OUT.glob("*.mp4"):
        if not p.is_file() or "_final_" not in p.name.lower():
            continue
        try:
            if p.parent.resolve() == UPSCALED_DIR.resolve():
                continue
        except Exception:
            pass
        job = job_name_from_final(p)
        if not job:
            continue
        prev = by_job.get(job)
        if prev is None or p.stat().st_mtime > prev.stat().st_mtime:
            by_job[job] = p
    pending = []
    for job, path in sorted(by_job.items(), key=lambda kv: kv[1].stat().st_mtime):
        if is_uploaded(job):
            continue
        pending.append((job, path))
    return pending


def upscale_1080_cpu(src: Path, dst: Path, ffmpeg: str) -> Path:
    dst.parent.mkdir(parents=True, exist_ok=True)
    print(f"CPU upscale 1080p:\n in={src}\n out={dst}")
    subprocess.run(
        [
            ffmpeg, "-y",
            "-i", str(src),
            "-vf", "scale=-2:1080",
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "18",
            "-c:a", "copy",
            "-movflags", "+faststart",
            str(dst),
        ],
        check=True,
        capture_output=True,
    )
    return dst


def _multipart(
    fields: dict[str, str],
    file_field: str,
    filename: str,
    file_bytes: bytes,
) -> tuple[str, bytes]:
    boundary = f"----ltx{uuid.uuid4().hex}"
    data = bytearray()
    for name, value in fields.items():
        data.extend(f"--{boundary}\r\n".encode())
        data.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        data.extend(value.encode("utf-8"))
        data.extend(b"\r\n")
    data.extend(f"--{boundary}\r\n".encode())
    data.extend(
        f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\n'.encode()
    )
    data.extend(b"Content-Type: application/octet-stream\r\n\r\n")
    data.extend(file_bytes)
    data.extend(b"\r\n")
    data.extend(f"--{boundary}--\r\n".encode())
    return boundary, bytes(data)


def _post_multipart(boundary: str, body: bytes, timeout: int | None = None) -> str:
    req = urllib.request.Request(
        UPLOAD_URL,
        data=body,
        headers={
            "User-Agent": "ltx-job-uploader/1.6",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(
        req, timeout=timeout or REQUEST_TIMEOUT, context=SSL_CTX
    ) as resp:
        return resp.read().decode("utf-8", errors="replace")


def server_upload_status(job_name: str) -> dict:
    try:
        data = urllib.parse.urlencode({
            "job_name": job_name,
            "action": "status",
            "client_version": CLIENT_VERSION,
        }).encode("utf-8")
        req = urllib.request.Request(
            UPLOAD_URL,
            data=data,
            headers={
                "User-Agent": "ltx-job-uploader/1.6",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as e:
        print(f" status check failed: {e}")
        return {}


def complete_job_on_server(job_name: str) -> bool:
    data = urllib.parse.urlencode({
        "action": "complete",
        "job_name": job_name,
        "client_version": CLIENT_VERSION,
    }).encode("utf-8")
    req = urllib.request.Request(
        COMPLETE_URL,
        data=data,
        headers={
            "User-Agent": "ltx-job-uploader/1.6",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        if text.strip() == "SERVER_UPDATED_CHECKER_MUST_UPDATE":
            print("*** complete blocked: SERVER PROTOCOL UPDATED — update checker ***")
            return False
        print(f" complete {job_name}: {text}")
        try:
            return bool(json.loads(text).get("ok"))
        except Exception:
            return "ok" in text.lower()
    except urllib.error.HTTPError as e:
        if e.code == 426:
            print("*** complete blocked: HTTP 426 upgrade required ***")
            return False
        print(f" complete failed for {job_name}: HTTP {e.code}")
        return False
    except Exception as e:
        print(f" complete failed for {job_name}: {e}")
        return False


def _upload_single(mp4: Path, job_name: str) -> None:
    boundary, body = _multipart(
        {"job_name": job_name},
        "file",
        mp4.name,
        mp4.read_bytes(),
    )
    text = _post_multipart(boundary, body)
    print(f"Upload response: {text}")
    if "\"ok\":false" in text.replace(" ", "").lower():
        raise RuntimeError(f"upload rejected: {text}")


def _upload_chunk_once(
    piece: bytes,
    job_name: str,
    filename: str,
    index: int,
    total: int,
    resume: bool,
) -> dict:
    fields = {
        "job_name": job_name,
        "filename": filename,
        "chunk_index": str(index),
        "total_chunks": str(total),
        "chunk_size": str(CHUNK_SIZE),
    }
    if resume or index > 0:
        fields["resume"] = "1"
    boundary, body = _multipart(fields, "file", f"{filename}.part{index}", piece)
    text = _post_multipart(boundary, body)
    print(f" chunk {index + 1}/{total} response: {text}")
    try:
        obj = json.loads(text)
    except Exception:
        raise RuntimeError(f"bad json: {text}")
    if not obj.get("ok"):
        raise RuntimeError(f"chunk {index} rejected: {text}")
    return obj


def _upload_chunk_with_retries(
    piece: bytes,
    job_name: str,
    filename: str,
    index: int,
    total: int,
    resume: bool,
) -> dict:
    last_err: Exception | None = None
    for attempt in range(1, CHUNK_RETRIES + 1):
        try:
            return _upload_chunk_once(piece, job_name, filename, index, total, resume)
        except Exception as e:
            last_err = e
            print(f" chunk {index + 1}/{total} attempt {attempt}/{CHUNK_RETRIES} failed: {e}")
            if attempt < CHUNK_RETRIES:
                time.sleep(CHUNK_RETRY_WAIT * attempt)
    raise RuntimeError(f"chunk {index} failed after {CHUNK_RETRIES} tries: {last_err}")


def upload_final(mp4: Path, job_name: str) -> None:
    size = mp4.stat().st_size
    if size <= SINGLE_MAX:
        print(f"Uploading (single) {mp4.name} ({size} bytes) job={job_name}")
        _upload_single(mp4, job_name)
        clear_progress(job_name)
        return
    total = (size + CHUNK_SIZE - 1) // CHUNK_SIZE
    prog = load_progress(job_name)
    start = int(prog.get("next_chunk", 0)) if prog.get("filename") == mp4.name else 0
    st = server_upload_status(job_name)
    part_bytes = int(st.get("part_bytes") or 0)
    if part_bytes > 0:
        server_next = part_bytes // CHUNK_SIZE
        if part_bytes % CHUNK_SIZE == 0 and server_next <= total:
            if server_next > start:
                start = server_next
            print(f" server has {part_bytes} bytes → resume chunk index {start}")
    if start >= total:
        start = 0
        print(" progress past end — restarting upload")
    print(
        f"Uploading (chunked) {mp4.name} ({size} bytes) "
        f"in {total} chunks; resuming at {start + 1}/{total}"
    )
    with mp4.open("rb") as f:
        if start > 0:
            f.seek(start * CHUNK_SIZE)
        for idx in range(start, total):
            piece = f.read(CHUNK_SIZE)
            if not piece:
                break
            print(f" sending chunk {idx + 1}/{total} ({len(piece)} bytes) …")
            resume = idx > 0 or start > 0
            _upload_chunk_with_retries(piece, job_name, mp4.name, idx, total, resume)
            save_progress(job_name, {
                "filename": mp4.name,
                "next_chunk": idx + 1,
                "total_chunks": total,
                "chunk_size": CHUNK_SIZE,
                "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
            })
    clear_progress(job_name)
    print(f"Chunked upload complete for {job_name}")


def postprocess_pending(ffmpeg: str) -> int:
    pending = list_pending_finals()
    if not pending:
        print("No pending finals to upscale/upload")
        return 0
    print(f"Pending finals: {len(pending)}")
    done = 0
    for job_name, src in pending:
        try:
            if is_uploaded(job_name):
                if not complete_job_on_server(job_name):
                    print(f" retry complete still failing for {job_name}")
                continue
            print(f"Postprocess '{job_name}': {src.name}")
            dst = UPSCALED_DIR / f"{src.stem}_1080p.mp4"
            if dst.is_file() and dst.stat().st_mtime >= src.stat().st_mtime:
                print(f" already upscaled: {dst.name}")
            else:
                upscale_1080_cpu(src, dst, ffmpeg)
            upload_final(dst, job_name)
            mark_uploaded(job_name)
            if not complete_job_on_server(job_name):
                print(
                    f" WARNING: upload OK but server complete failed for {job_name} "
                    f"(will retry complete on later loops)"
                )
            else:
                print(f" done + completed on server: {job_name}")
            done += 1
        except subprocess.CalledProcessError as e:
            err = e.stderr
            if isinstance(err, bytes):
                err = err.decode(errors="replace")
            print(f" ffmpeg failed for {job_name}: {e}\n{err}")
            print(f" will retry later (sleep {UPLOAD_FAIL_WAIT}s)")
            time.sleep(UPLOAD_FAIL_WAIT)
        except Exception as e:
            print(f" failed for {job_name}: {e}")
            print(f" progress saved — will resume later (sleep {UPLOAD_FAIL_WAIT}s)")
            time.sleep(UPLOAD_FAIL_WAIT)
    return done


def claim_url() -> str:
    params: dict[str, str] = {
        "max_seconds": str(int(MAX_SECONDS)),
        "accept_audio": "1" if ACCEPT_AUDIO else "0",
        "client_version": CLIENT_VERSION,
    }
    # Optional identity — server logs into the claimed job folder
    if WORKER_ID:
        params["worker_id"] = WORKER_ID
    if NCZ_ADDRESS:
        params["ncz_address"] = NCZ_ADDRESS
    q = urllib.parse.urlencode(params)
    sep = "&" if "?" in PROCESS_URL else "?"
    return PROCESS_URL + sep + q


def fetch_once() -> str:
    url = claim_url()
    print(f"Claim URL: {url}")
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "ltx-job-fetcher/1.6",
            "Accept": "application/zip,*/*",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            ctype = (resp.headers.get("Content-Type") or "").lower()
            disp = resp.headers.get("Content-Disposition") or ""
            job_status = resp.headers.get("X-Job-Status") or ""
            need_ver = resp.headers.get("X-Protocol-Version") or "?"
            body = resp.read()
            if (
                status == 426
                or job_status == "upgrade"
                or body.strip() == b"SERVER_UPDATED_CHECKER_MUST_UPDATE"
            ):
                print(
                    "*** SERVER PROTOCOL UPDATED ***\n"
                    f" this checker: {CLIENT_VERSION}\n"
                    f" server wants: {need_ver}\n"
                    " Update check.py (CLIENT_VERSION) / scripts, restart.\n"
                    " Not claiming jobs until versions match."
                )
                return "upgrade"
            if status == 204 or job_status == "empty" or body.strip() == b"NO_JOB":
                print(
                    f"No matching job (max_seconds={MAX_SECONDS}, "
                    f"accept_audio={int(ACCEPT_AUDIO)}, version={CLIENT_VERSION})."
                )
                return "empty"
            if status == 409 or job_status == "race" or body.strip() == b"CLAIM_RACE":
                print("Claim race (another worker took it) — retry soon.")
                return "race"
            if status != 200:
                print(f"Unexpected HTTP {status}: {body[:200]!r}")
                return "error"
            filename = "job.zip"
            if "filename=" in disp:
                part = disp.split("filename=", 1)[1].strip().strip('"')
                if part:
                    filename = os.path.basename(part)
            if "zip" not in ctype and not filename.lower().endswith(".zip"):
                if not body.startswith(b"PK"):
                    text = body[:80].decode("utf-8", errors="replace")
                    print(f"Not a zip: {text!r}")
                    if "SERVER_UPDATED_CHECKER_MUST_UPDATE" in text:
                        return "upgrade"
                    if "NO_JOB" in text:
                        return "empty"
                    if "CLAIM_RACE" in text:
                        return "race"
                    return "error"
            dest = QUEUE_DIR / filename
            if dest.exists():
                dest = QUEUE_DIR / f"{dest.stem}_{int(time.time())}.zip"
            dest.write_bytes(body)
            print(f"Saved {dest} ({len(body)} bytes)")
            return "saved"
    except urllib.error.HTTPError as e:
        if e.code == 426:
            need = e.headers.get("X-Protocol-Version") if e.headers else "?"
            print(
                "*** SERVER PROTOCOL UPDATED (HTTP 426) ***\n"
                f" this checker: {CLIENT_VERSION}\n"
                f" server wants: {need}\n"
                " Update scripts and restart."
            )
            return "upgrade"
        if e.code == 204:
            print("No matching job (204).")
            return "empty"
        if e.code == 409:
            print("Claim race (409).")
            return "race"
        try:
            err_body = e.read()[:200]
        except Exception:
            err_body = b""
        print(f"HTTPError {e.code}: {err_body!r}")
        return "error"
    except urllib.error.URLError as e:
        print(f"URLError: {e}")
        return "error"
    except Exception as e:
        print(f"Error: {e}")
        return "error"


def main() -> int:
    ensure_dirs()
    ffmpeg = require_ffmpeg()
    print(f"Polling {PROCESS_URL}")
    print(
        f"FLAGS: MAX_SECONDS={MAX_SECONDS} ACCEPT_AUDIO={ACCEPT_AUDIO} "
        f"CLIENT_VERSION={CLIENT_VERSION}"
    )
    print(f"WORKER_ID: {WORKER_ID or '(none — set WORKER_ID for contact)'}")
    print(f"NCZ_ADDRESS: {NCZ_ADDRESS or '(none — set NCZ_ADDRESS for payouts)'}")
    print(f"Complete URL: {COMPLETE_URL}")
    print(f"Upload URL: {UPLOAD_URL}")
    print(f"Chunk size: {CHUNK_SIZE} | retries/chunk: {CHUNK_RETRIES}")
    print("Startup scan for pending finals …")
    postprocess_pending(ffmpeg)
    while True:
        postprocess_pending(ffmpeg)
        zips = local_zips()
        if zips:
            print(f"Queue has {len(zips)} zip(s) — not contacting server. Sleep {BUSY_WAIT}s …")
            time.sleep(BUSY_WAIT)
            continue
        print("Queue empty — requesting filtered job from server …")
        result = fetch_once()
        postprocess_pending(ffmpeg)
        if result == "saved":
            continue
        if result == "race":
            time.sleep(3)
            continue
        if result == "upgrade":
            print(f"Sleeping {UPGRADE_WAIT}s (waiting for script update) …")
            time.sleep(UPGRADE_WAIT)
            continue
        print(f"Sleeping {EMPTY_WAIT}s …")
        time.sleep(EMPTY_WAIT)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nStopped.")
        sys.exit(0)