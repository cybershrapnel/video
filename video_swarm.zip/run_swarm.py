"""
start_service.py — start swarm worker + checker together

Run from the same folder as:
  - worker.py  (worker)
  - checker.py (checker)

Optional env:
  COMFY_URL, COMFY_INPUT_DIR, MAX_SECONDS, ACCEPT_AUDIO, etc.
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PYTHON = sys.executable

WORKER = HERE / "worker.py"
CHECKER = HERE / "checker.py"

# Restart a child if it exits (set 0 to disable auto-restart)
RESTART_DELAY = float(os.environ.get("RESTART_DELAY", "5"))
AUTO_RESTART = os.environ.get("AUTO_RESTART", "1").strip() not in ("0", "false", "no")


def spawn(script: Path, name: str) -> subprocess.Popen:
    if not script.is_file():
        raise FileNotFoundError(f"Missing {script}")
    print(f"[start] {name}: {PYTHON} {script.name}")
    # New process group on Windows so we can stop children cleanly
    kwargs = {
        "cwd": str(HERE),
        "env": os.environ.copy(),
    }
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    else:
        kwargs["start_new_session"] = True
    return subprocess.Popen([PYTHON, str(script)], **kwargs)


def stop_proc(p: subprocess.Popen | None, name: str) -> None:
    if p is None or p.poll() is not None:
        return
    print(f"[stop] {name} pid={p.pid}")
    try:
        if os.name == "nt":
            p.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
            try:
                p.wait(timeout=8)
            except subprocess.TimeoutExpired:
                p.kill()
        else:
            p.terminate()
            try:
                p.wait(timeout=8)
            except subprocess.TimeoutExpired:
                p.kill()
    except Exception as e:
        print(f"[stop] {name} error: {e}")
        try:
            p.kill()
        except Exception:
            pass


def main() -> int:
    print("=" * 60)
    print("LTX swarm service")
    print(f" cwd: {HERE}")
    print(f" python: {PYTHON}")
    print(f" worker: {WORKER.name}")
    print(f" checker: {CHECKER.name}")
    print(f" auto-restart: {AUTO_RESTART} (delay {RESTART_DELAY}s)")
    print("=" * 60)

    worker: subprocess.Popen | None = None
    checker: subprocess.Popen | None = None
    stopping = False

    def handle_signal(signum, frame):
        nonlocal stopping
        if stopping:
            return
        stopping = True
        print(f"\n[signal] {signum} — shutting down…")
        stop_proc(worker, "worker")
        stop_proc(checker, "checker")

    if os.name == "nt":
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        try:
            signal.signal(signal.SIGBREAK, handle_signal)  # type: ignore[attr-defined]
        except Exception:
            pass
    else:
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)

    try:
        worker = spawn(WORKER, "worker")
        time.sleep(1.0)
        checker = spawn(CHECKER, "checker")
    except Exception as e:
        print(f"[fatal] could not start: {e}")
        stop_proc(worker, "worker")
        stop_proc(checker, "checker")
        return 1

    print("[ok] both processes running — Ctrl+C to stop")
    while not stopping:
        time.sleep(2.0)

        if worker is not None and worker.poll() is not None:
            code = worker.returncode
            print(f"[exit] worker code={code}")
            if stopping:
                break
            if not AUTO_RESTART:
                print("[halt] worker died and AUTO_RESTART=0")
                stopping = True
                break
            print(f"[restart] worker in {RESTART_DELAY}s…")
            time.sleep(RESTART_DELAY)
            if stopping:
                break
            try:
                worker = spawn(WORKER, "worker")
            except Exception as e:
                print(f"[restart] worker failed: {e}")
                worker = None

        if checker is not None and checker.poll() is not None:
            code = checker.returncode
            print(f"[exit] checker code={code}")
            if stopping:
                break
            if not AUTO_RESTART:
                print("[halt] checker died and AUTO_RESTART=0")
                stopping = True
                break
            print(f"[restart] checker in {RESTART_DELAY}s…")
            time.sleep(RESTART_DELAY)
            if stopping:
                break
            try:
                checker = spawn(CHECKER, "checker")
            except Exception as e:
                print(f"[restart] checker failed: {e}")
                checker = None

    stop_proc(worker, "worker")
    stop_proc(checker, "checker")
    print("[done]")
    return 0


if __name__ == "__main__":
    sys.exit(main())