"""
run_audio_queue.py — LTX audio + no-audio queue worker
Watches ./queue for .zip jobs forever.

Patched API JSON dumps go to swarm-data/patched_api/ (not Comfy root).

INPUT_DIR resolution (first hit wins):
  1) COMFY_INPUT_DIR env
  2) %LOCALAPPDATA%\\Comfy-Desktop\\ComfyUI-Shared\\input
  3) Common Comfy Desktop install ...\\ComfyUI\\input folders
  4) ./input next to this script
"""
from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
import time
import uuid
import zipfile
from pathlib import Path

import urllib.error
import urllib.request

# ───────────────────────── config ─────────────────────────
COMFY_URL = os.environ.get("COMFY_URL", "http://127.0.0.1:8188").rstrip("/")
WORKFLOW_FILE = os.environ.get("WORKFLOW_FILE", "ltx_23_audio.json")
WORKFLOW_NO_AUDIO = os.environ.get("WORKFLOW_NO_AUDIO", "ltx_23_no_audio.json")
CLIP_LENGTH = 45
FPS = 24
POLL_SECONDS = 3.0
QUEUE_POLL_SECONDS = 10.0

NODE_POS = "121"
NODE_NEG = "593"
NODE_CLIP_LOADER = "146"
NODE_SECONDS = "196"
NODE_ORCHESTRATOR = "1353"
NODE_LOAD_IMAGES = ("149", "786", "1705")
NODE_VIDEO_OUT = "188"

QUEUE_DIR = Path("queue")
COMPLETED_DIR = QUEUE_DIR / "completed"
WORK_DIR = QUEUE_DIR / "_work"
CHUNK_DIR = Path("audio_chunks")
FINAL_OUT = Path("output_concat")

# Patched workflow JSON dumps only
SWARM_DATA = Path(os.environ.get("SWARM_DATA", "swarm-data"))
PATCHED_DIR = SWARM_DATA / "patched_api"

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


# ──────────────────────────────────────────────────────────
def resolve_input_dir() -> Path:
    """
    Put staged LoadImage/LoadAudio files where THIS ComfyUI actually reads input.
    """
    candidates: list[Path] = []

    env = os.environ.get("COMFY_INPUT_DIR")
    if env:
        candidates.append(Path(env))

    localapp = os.environ.get("LOCALAPPDATA", "")
    userprofile = os.environ.get("USERPROFILE", "")

    if localapp:
        candidates.append(Path(localapp) / "Comfy-Desktop" / "ComfyUI-Shared" / "input")
        base = Path(localapp) / "Comfy-Desktop" / "ComfyUI-Installs"
        if base.is_dir():
            for p in base.rglob("input"):
                if p.is_dir() and p.name.lower() == "input" and p.parent.name.lower() == "comfyui":
                    candidates.append(p)

    if userprofile:
        candidates.append(
            Path(userprofile)
            / "AppData"
            / "Local"
            / "Comfy-Desktop"
            / "ComfyUI-Shared"
            / "input"
        )

    candidates.append(
        Path(r"C:\Users\admin\AppData\Local\Comfy-Desktop\ComfyUI-Shared\input")
    )
    candidates.append(
        Path(
            r"C:\Users\cybershrapnel\AppData\Local\Comfy-Desktop\ComfyUI-Installs\ComfyUI\ComfyUI\input"
        )
    )
    candidates.append(
        Path(r"C:\Users\cybershrapnel\AppData\Local\Comfy-Desktop\ComfyUI-Shared\input")
    )

    candidates.append(Path.cwd() / "input")
    candidates.append(Path(__file__).resolve().parent / "input")

    seen: set[str] = set()
    existing: list[Path] = []
    for c in candidates:
        try:
            key = str(c.resolve()) if c.exists() else str(c)
        except Exception:
            key = str(c)
        if key in seen:
            continue
        seen.add(key)
        if c.is_dir():
            existing.append(c)

    if existing:
        chosen = existing[0]
        print(f"INPUT_DIR (existing): {chosen}")
        return chosen

    if localapp:
        preferred = Path(localapp) / "Comfy-Desktop" / "ComfyUI-Shared" / "input"
    else:
        preferred = Path.cwd() / "input"
    preferred.mkdir(parents=True, exist_ok=True)
    print(f"INPUT_DIR (created): {preferred}")
    print(
        "NOTE: If Comfy uses a different input folder, set COMFY_INPUT_DIR to the path "
        "printed in Comfy log: 'Setting input directory to: ...'"
    )
    return preferred


INPUT_DIR = resolve_input_dir()


def http_json(method: str, path: str, data: dict | None = None, timeout: float = 120.0) -> dict:
    url = f"{COMFY_URL}{path}"
    body = None
    headers = {"Accept": "application/json"}
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {path}: {err_body}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach ComfyUI at {COMFY_URL}: {e}") from e


def comfy_up() -> bool:
    try:
        http_json("GET", "/system_stats", timeout=5)
        return True
    except Exception:
        return False


def which(cmd: str) -> str | None:
    from shutil import which as _which
    return _which(cmd)


def require_ffmpeg() -> tuple[str, str]:
    ff, fp = which("ffmpeg"), which("ffprobe")
    if not ff or not fp:
        raise RuntimeError("ffmpeg/ffprobe not on PATH")
    return ff, fp


def audio_duration_seconds(path: Path, ffprobe: str) -> float:
    r = subprocess.run(
        [
            ffprobe, "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
        ],
        capture_output=True, text=True, check=True,
    )
    return float(r.stdout.strip())


def split_audio(src: Path, chunk_sec: int, out_dir: Path, ffmpeg: str, ffprobe: str) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    for old in out_dir.glob("chunk_*.mp3"):
        old.unlink()
    dur = audio_duration_seconds(src, ffprobe)
    print(f"Audio duration: {dur:.2f}s | segment size: {chunk_sec}s")
    if dur <= chunk_sec + 0.05:
        dst = out_dir / "chunk_000.mp3"
        shutil.copy2(src, dst)
        return [dst]
    pattern = str(out_dir / "chunk_%03d.mp3")
    subprocess.run(
        [
            ffmpeg, "-y", "-i", str(src),
            "-f", "segment",
            "-segment_time", str(chunk_sec),
            "-reset_timestamps", "1",
            "-c", "copy",
            pattern,
        ],
        check=True, capture_output=True,
    )
    chunks = sorted(out_dir.glob("chunk_*.mp3"))
    if not chunks:
        raise RuntimeError("ffmpeg produced no audio chunks")
    print(f"Split into {len(chunks)} chunk(s)")
    return chunks


def read_text(path: Path, default: str = "") -> str:
    return path.read_text(encoding="utf-8").strip() if path.is_file() else default


def job_clip_length(root: Path, default: int = 45) -> int:
    candidates: list[Path] = []
    direct = root / "seconds.txt"
    if direct.is_file():
        candidates.append(direct)
    try:
        for p in root.rglob("seconds.txt"):
            if p.is_file() and p not in candidates:
                candidates.append(p)
        for p in root.rglob("Seconds.txt"):
            if p.is_file() and p not in candidates:
                candidates.append(p)
    except Exception as e:
        print(f"WARNING: rglob for seconds.txt failed: {e}")
    if not candidates:
        print(f"seconds.txt NOT FOUND under {root.resolve()}")
        return default
    p = candidates[0]
    try:
        raw_full = p.read_text(encoding="utf-8-sig").strip()
        raw = raw_full.split()[0] if raw_full else ""
        print(f"seconds.txt at {p} raw={raw_full!r}")
        if not raw:
            return default
        n = int(float(raw))
    except Exception as e:
        print(f"WARNING: bad seconds.txt at {p}: {e} — using default {default}")
        return default
    n = max(5, min(45, n))
    print(f"seconds.txt → clip_len={n}")
    return n


def load_workflow(path: str) -> dict:
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Workflow not found: {p.resolve()}")
    with p.open(encoding="utf-8") as f:
        return json.load(f)


def is_api_prompt(obj: dict) -> bool:
    if not obj or not isinstance(obj, dict) or "nodes" in obj or "links" in obj:
        return False
    sample = next(iter(obj.values()), None)
    return isinstance(sample, dict) and "class_type" in sample


def stage_into_input(src: Path, dest_name: str | None = None) -> str:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    name = dest_name or src.name
    dst = INPUT_DIR / name
    if not src.is_file():
        raise FileNotFoundError(f"Cannot stage missing file: {src}")
    if src.resolve() != dst.resolve():
        shutil.copy2(src, dst)
    if not dst.is_file():
        raise RuntimeError(f"Stage failed — not present: {dst}")
    print(f" staged {name} -> {dst} ({dst.stat().st_size} bytes)")
    return name


def iter_nodes(prompt: dict):
    for nid, node in prompt.items():
        if isinstance(node, dict):
            yield str(nid), node.get("class_type", ""), node.setdefault("inputs", {})


def frames_from_seconds(seconds: float) -> int:
    return int(round(float(seconds) * FPS)) + 1


def deep_copy_prompt(prompt: dict) -> dict:
    return json.loads(json.dumps(prompt))


def last_chunk_video_seconds(chunk_dur: float) -> int:
    return int(math.ceil(chunk_dur) + 1)


def is_image_file(p: Path) -> bool:
    return p.is_file() and p.suffix.lower() in IMAGE_EXTS


def list_images_in_dir(folder: Path, recursive: bool = False) -> list[Path]:
    if not folder.is_dir():
        return []
    if recursive:
        files = [p for p in folder.rglob("*") if is_image_file(p)]
    else:
        files = [p for p in folder.iterdir() if is_image_file(p)]
    return sorted(files, key=lambda p: p.name.lower())


def extract_zip(zip_path: Path, dest: Path) -> Path:
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(dest)
    children = [p for p in dest.iterdir() if not p.name.startswith(".")]
    if len(children) == 1 and children[0].is_dir():
        return children[0]
    return dest


def parse_job_folder(root: Path) -> dict:
    promp = root / "promp.txt"
    anti = root / "anti.txt"
    if not promp.is_file():
        alt = root / "prompt.txt"
        if alt.is_file():
            promp = alt
        else:
            raise RuntimeError(f"Missing promp.txt in {root}")
    if not anti.is_file():
        raise RuntimeError(f"Missing anti.txt in {root}")

    mp3s = sorted(root.glob("*.mp3"), key=lambda p: p.name.lower())
    if not mp3s:
        mp3s = sorted(root.rglob("*.mp3"), key=lambda p: p.name.lower())
    noaudio_marker = (root / "noaudio.txt").is_file()
    mp3 = mp3s[0] if mp3s else None
    no_audio = mp3 is None
    if mp3 is None and not noaudio_marker:
        print("NOTE: no .mp3 and no noaudio.txt — treating as no-audio job")

    root_images = list_images_in_dir(root, recursive=False)
    image_folders: list[tuple[Path, list[Path]]] = []
    for d in sorted([p for p in root.iterdir() if p.is_dir()], key=lambda p: p.name.lower()):
        imgs = list_images_in_dir(d, recursive=True)
        if imgs:
            image_folders.append((d, imgs))

    if root_images:
        mode = "static"
        sorted_imgs = sorted(root_images, key=lambda p: p.name.lower())
        if len(sorted_imgs) == 1:
            static = [sorted_imgs[0], sorted_imgs[0], sorted_imgs[0]]
        else:
            static = list(sorted_imgs[:3])
            while len(static) < 3:
                static.append(static[-1])
        rotate_images: list[Path] = []
        print(f"Image mode: STATIC ({len(sorted_imgs)} root image(s))")
        for i, p in enumerate(static, 1):
            print(f" image{i} <- {p.name}")
    elif image_folders:
        mode = "rotate"
        preferred = None
        for d, imgs in image_folders:
            if d.name.lower() in ("images", "image", "frames", "imgs", "pics"):
                preferred = imgs
                break
        rotate_images = preferred if preferred is not None else image_folders[0][1]
        static = []
        print(f"Image mode: ROTATE ({len(rotate_images)} images in folder)")
    else:
        raise RuntimeError(f"No images at zip root and no image folder found in {root}")

    return {
        "positive": read_text(promp),
        "negative": read_text(anti),
        "mp3": mp3,
        "no_audio": no_audio,
        "mode": mode,
        "static_images": static,
        "rotate_images": rotate_images,
    }


def images_for_chunk(job: dict, chunk_index: int) -> list[Path]:
    if job["mode"] == "static":
        return list(job["static_images"])
    pool: list[Path] = job["rotate_images"]
    if not pool:
        raise RuntimeError("rotate mode but no images")
    img = pool[chunk_index % len(pool)]
    return [img, img, img]


def patch_prompt(
    prompt: dict,
    *,
    image_names: list[str],
    audio_name: str | None,
    positive: str,
    negative: str,
    clip_seconds: float,
    use_audio: bool,
) -> dict:
    frames = frames_from_seconds(clip_seconds)
    sec_int = max(1, int(round(clip_seconds)))
    load_image_nodes, load_audio_nodes, length_nodes = [], [], []
    for nid, ctype, inputs in iter_nodes(prompt):
        cl = ctype.lower()
        if ctype in ("LoadImage", "LoadImageMask") or "loadimage" in cl:
            load_image_nodes.append((nid, inputs))
        if "loadaudio" in cl or ctype in ("LoadAudio", "VHS_LoadAudio", "LoadAudio|audio"):
            load_audio_nodes.append((nid, inputs))
        for key in list(inputs.keys()):
            if key.lower() in (
                "length", "frames", "num_frames", "frame_count",
                "seconds", "duration", "clip_length",
            ):
                length_nodes.append((nid, ctype, inputs, key))

    ordered, used = [], set()
    for want in NODE_LOAD_IMAGES:
        for nid, inputs in load_image_nodes:
            if nid == want:
                ordered.append((nid, inputs))
                used.add(nid)
                break
    for nid, inputs in load_image_nodes:
        if nid not in used:
            ordered.append((nid, inputs))

    for i, name in enumerate(image_names[:3]):
        if i < len(ordered):
            nid, inputs = ordered[i]
            inputs["image"] = name
            print(f" LoadImage {nid} -> {name}")

    if NODE_ORCHESTRATOR in prompt and isinstance(prompt[NODE_ORCHESTRATOR].get("inputs"), dict):
        prompt[NODE_ORCHESTRATOR]["inputs"]["Audio input"] = bool(use_audio and audio_name)
        print(f" Orchestrator Audio input -> {prompt[NODE_ORCHESTRATOR]['inputs']['Audio input']}")

    if use_audio and audio_name:
        if load_audio_nodes:
            for nid, inputs in load_audio_nodes:
                for key in ("audio", "path", "file", "audio_path", "audio_file"):
                    if key in inputs:
                        inputs[key] = audio_name
                        break
                else:
                    inputs["audio"] = audio_name
                print(f" LoadAudio {nid} -> {audio_name}")
        else:
            print("WARNING: no LoadAudio node in API graph")

    if NODE_SECONDS in prompt and isinstance(prompt[NODE_SECONDS].get("inputs"), dict):
        prompt[NODE_SECONDS]["inputs"]["Xi"] = sec_int
        prompt[NODE_SECONDS]["inputs"]["Xf"] = float(sec_int)
        print(f" node {NODE_SECONDS} seconds -> {sec_int}")

    for nid, ctype, inputs, key in length_nodes:
        lk = key.lower()
        if ctype == "EmptyLTXVLatentVideo" and lk == "length":
            inputs[key] = frames
            print(f" {nid}.length FRAMES -> {frames}")
            continue
        if lk in ("seconds", "duration", "clip_length"):
            inputs[key] = sec_int
            print(f" {nid}.{key} seconds -> {sec_int}")
        elif lk in ("length", "frames", "num_frames", "frame_count"):
            inputs[key] = frames
            print(f" {nid}.{key} frames -> {frames}")

    clip_ref = [NODE_CLIP_LOADER, 0]
    if NODE_POS in prompt and isinstance(prompt[NODE_POS].get("inputs"), dict):
        prompt[NODE_POS]["inputs"]["clip"] = clip_ref
        if positive:
            prompt[NODE_POS]["inputs"]["text"] = positive
        print(f" {NODE_POS} positive + clip")
    if NODE_NEG in prompt and isinstance(prompt[NODE_NEG].get("inputs"), dict):
        prompt[NODE_NEG]["inputs"]["clip"] = clip_ref
        if negative:
            prompt[NODE_NEG]["inputs"]["text"] = negative
        print(f" {NODE_NEG} negative + clip")
    for nid, ctype, inputs in iter_nodes(prompt):
        if (ctype == "CLIPTextEncode" or "cliptextencode" in ctype.lower()) and "clip" not in inputs:
            inputs["clip"] = clip_ref
    return prompt


def queue_prompt(prompt: dict, client_id: str) -> str:
    out = http_json("POST", "/prompt", {"prompt": prompt, "client_id": client_id})
    print("/prompt:", {k: out.get(k) for k in ("prompt_id", "number", "error", "node_errors")})
    if out.get("error") or out.get("node_errors"):
        raise RuntimeError(str(out))
    pid = out.get("prompt_id")
    if not pid:
        raise RuntimeError(f"No prompt_id: {out}")
    return pid


def wait_for_prompt(prompt_id: str) -> dict:
    print(f"Waiting for {prompt_id} …")
    while True:
        q = http_json("GET", "/queue")
        still = prompt_id in (
            json.dumps(q.get("queue_running") or []) + json.dumps(q.get("queue_pending") or [])
        )
        hist = http_json("GET", f"/history/{prompt_id}")
        if prompt_id in hist:
            return hist[prompt_id]
        if not still:
            hist_all = http_json("GET", "/history")
            if prompt_id in hist_all:
                return hist_all[prompt_id]
            raise RuntimeError(f"{prompt_id} left queue with no history")
        print(".", end="", flush=True)
        time.sleep(POLL_SECONDS)


def collect_video_files(result: dict) -> list[Path]:
    found: list[Path] = []
    outputs = result.get("outputs") or {}
    names: list[tuple[str, str]] = []
    for out in outputs.values():
        if not isinstance(out, dict):
            continue
        for key in ("gifs", "videos", "images"):
            for item in out.get(key) or []:
                if isinstance(item, dict) and item.get("filename"):
                    if item.get("fullpath") and Path(item["fullpath"]).is_file():
                        found.append(Path(item["fullpath"]).resolve())
                    else:
                        names.append((item["filename"], item.get("subfolder") or ""))

    localapp = os.environ.get("LOCALAPPDATA", "")
    roots = [
        Path("output"),
        Path.cwd() / "output",
    ]
    if localapp:
        roots.append(Path(localapp) / "Comfy-Desktop" / "ComfyUI-Shared" / "output")
        base = Path(localapp) / "Comfy-Desktop" / "ComfyUI-Installs"
        if base.is_dir():
            for p in base.rglob("output"):
                if p.is_dir() and p.name.lower() == "output" and p.parent.name.lower() == "comfyui":
                    roots.append(p)

    roots.extend([
        Path(r"C:\Users\admin\AppData\Local\Comfy-Desktop\ComfyUI-Shared\output"),
        Path(r"C:\Users\cybershrapnel\AppData\Local\Comfy-Desktop\ComfyUI-Shared\output"),
    ])

    for filename, sub in names:
        for root in roots:
            p = (root / sub / filename) if sub else (root / filename)
            if p.is_file():
                found.append(p.resolve())

    seen, uniq = set(), []
    for p in found:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def concat_videos(videos: list[Path], out_file: Path, ffmpeg: str) -> Path:
    if not videos:
        raise RuntimeError("No videos to concat")
    out_file.parent.mkdir(parents=True, exist_ok=True)
    if len(videos) == 1:
        shutil.copy2(videos[0], out_file)
        return out_file
    list_file = out_file.parent / "concat_list.txt"
    with list_file.open("w", encoding="utf-8") as f:
        for v in videos:
            f.write(f"file '{v.resolve().as_posix()}'\n")
    subprocess.run(
        [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(list_file), "-c", "copy", str(out_file)],
        check=True, capture_output=True,
    )
    return out_file


def mux_original_audio(video: Path, original_mp3: Path, out_file: Path, ffmpeg: str) -> Path:
    out_file.parent.mkdir(parents=True, exist_ok=True)
    print(f"Remuxing original audio:\n video={video}\n audio={original_mp3}\n out={out_file}")
    subprocess.run(
        [
            ffmpeg, "-y",
            "-i", str(video),
            "-i", str(original_mp3),
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-c:v", "copy",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            str(out_file),
        ],
        check=True,
        capture_output=True,
    )
    return out_file


def run_one_job(
    base_prompt: dict,
    *,
    image_names: list[str],
    audio_name: str | None,
    positive: str,
    negative: str,
    clip_seconds: float,
    use_audio: bool,
    tag: str,
) -> list[Path]:
    prompt = deep_copy_prompt(base_prompt)
    if NODE_VIDEO_OUT in prompt and isinstance(prompt[NODE_VIDEO_OUT].get("inputs"), dict):
        prompt[NODE_VIDEO_OUT]["inputs"]["filename_prefix"] = f"ltx2_{tag}"
    prompt = patch_prompt(
        prompt,
        image_names=image_names,
        audio_name=audio_name,
        positive=positive,
        negative=negative,
        clip_seconds=clip_seconds,
        use_audio=use_audio,
    )
    PATCHED_DIR.mkdir(parents=True, exist_ok=True)
    patched_path = PATCHED_DIR / f"ltx23_patched_api_{tag}.json"
    patched_path.write_text(json.dumps(prompt, indent=2), encoding="utf-8")
    print(f" patched api → {patched_path}")

    pid = queue_prompt(prompt, str(uuid.uuid4()))
    print(f"[{tag}] Prompt ID: {pid} | clip_seconds={clip_seconds:.2f}")
    result = wait_for_prompt(pid)
    status = (result.get("status") or {}).get("status_str")
    print(f"\n[{tag}] status={status}")
    if status == "error":
        for msg in (result.get("status") or {}).get("messages") or []:
            if isinstance(msg, list) and msg and msg[0] == "execution_error":
                print("EXECUTION ERROR:", msg[1].get("exception_message"))
        raise RuntimeError(f"Job {tag} failed")
    vids = collect_video_files(result)
    print(f"[{tag}] videos:", [str(v) for v in vids])
    return vids


def list_pending_zips() -> list[Path]:
    if not QUEUE_DIR.is_dir():
        return []
    zips = [p for p in QUEUE_DIR.iterdir() if p.is_file() and p.suffix.lower() == ".zip"]
    return sorted(zips, key=lambda p: p.stat().st_mtime)


def process_zip(
    zip_path: Path,
    base_prompt_audio: dict,
    base_prompt_noaudio: dict | None,
    ffmpeg: str,
    ffprobe: str,
) -> Path:
    print("\n" + "=" * 60)
    print(f"JOB ZIP: {zip_path.name}")
    print(f"INPUT_DIR: {INPUT_DIR.resolve()}")
    print("=" * 60)
    work = WORK_DIR / zip_path.stem
    if work.exists():
        shutil.rmtree(work)
    root = extract_zip(zip_path, work)
    print(f"Extracted root: {root}")

    job = parse_job_folder(root)
    positive = job["positive"]
    negative = job["negative"]
    no_audio = bool(job.get("no_audio") or job.get("mp3") is None)
    clip_len = job_clip_length(root, CLIP_LENGTH)
    print(f"No-audio: {no_audio} | clip_len={clip_len}s")
    FINAL_OUT.mkdir(parents=True, exist_ok=True)

    if no_audio:
        if base_prompt_noaudio is None:
            raise RuntimeError(f"No-audio job but {WORKFLOW_NO_AUDIO} not loaded")
        img_paths = images_for_chunk(job, 0)
        image_names = []
        for slot, img in enumerate(img_paths, 1):
            staged = f"{zip_path.stem}_image{slot}{img.suffix.lower()}"
            image_names.append(stage_into_input(img, dest_name=staged))
        tag = f"{zip_path.stem}_noaudio"
        vids = run_one_job(
            base_prompt_noaudio,
            image_names=image_names,
            audio_name=None,
            positive=positive,
            negative=negative,
            clip_seconds=float(clip_len),
            use_audio=False,
            tag=tag,
        )
        if not vids:
            raise RuntimeError("No video for no-audio job")
        stamp = time.strftime("%Y%m%d_%H%M%S")
        final_path = FINAL_OUT / f"{zip_path.stem}_final_{stamp}.mp4"
        shutil.copy2(vids[0], final_path)
        print(f"FINAL (no-audio): {final_path.resolve()}")
        try:
            shutil.rmtree(work)
        except Exception as e:
            print(f"WARNING: could not remove work dir: {e}")
        return final_path

    audio_src = job["mp3"]
    original_audio_copy = FINAL_OUT / f"_src_{zip_path.stem}.mp3"
    shutil.copy2(audio_src, original_audio_copy)
    chunks = split_audio(audio_src, clip_len, CHUNK_DIR, ffmpeg, ffprobe)
    segment_videos: list[Path] = []
    for i, chunk in enumerate(chunks):
        tag = f"{zip_path.stem}_chunk{i:03d}"
        is_last = i == len(chunks) - 1
        chunk_dur = audio_duration_seconds(chunk, ffprobe)
        if is_last:
            clip_seconds = float(last_chunk_video_seconds(chunk_dur))
            print(f"\n===== LAST CHUNK {tag}: audio={chunk_dur:.3f}s -> video={clip_seconds:.0f}s =====")
        else:
            clip_seconds = float(clip_len)
            print(f"\n===== CHUNK {i+1}/{len(chunks)} {tag}: video={clip_seconds:.0f}s =====")
        img_paths = images_for_chunk(job, i)
        image_names = []
        for slot, img in enumerate(img_paths, 1):
            staged_name = f"{zip_path.stem}_c{i:03d}_image{slot}{img.suffix.lower()}"
            image_names.append(stage_into_input(img, dest_name=staged_name))
        staged_audio = stage_into_input(chunk, dest_name=f"{zip_path.stem}_audio_chunk{i:03d}.mp3")
        vids = run_one_job(
            base_prompt_audio,
            image_names=image_names,
            audio_name=staged_audio,
            positive=positive,
            negative=negative,
            clip_seconds=clip_seconds,
            use_audio=True,
            tag=tag,
        )
        if not vids:
            raise RuntimeError(f"No video for {tag}")
        segment_videos.append(vids[0])

    stamp = time.strftime("%Y%m%d_%H%M%S")
    concat_path = FINAL_OUT / f"{zip_path.stem}_concat_{stamp}.mp4"
    concat_videos(segment_videos, concat_path, ffmpeg)
    final_path = FINAL_OUT / f"{zip_path.stem}_final_{stamp}.mp4"
    mux_original_audio(concat_path, original_audio_copy, final_path, ffmpeg)
    print(f"FINAL (original mp3): {final_path.resolve()}")
    try:
        shutil.rmtree(work)
    except Exception as e:
        print(f"WARNING: could not remove work dir: {e}")
    try:
        original_audio_copy.unlink(missing_ok=True)
    except Exception:
        pass
    return final_path


def move_to_completed(zip_path: Path) -> Path:
    COMPLETED_DIR.mkdir(parents=True, exist_ok=True)
    dest = COMPLETED_DIR / zip_path.name
    if dest.exists():
        dest = COMPLETED_DIR / f"{zip_path.stem}_{time.strftime('%Y%m%d_%H%M%S')}{zip_path.suffix}"
    shutil.move(str(zip_path), str(dest))
    print(f"Moved to completed: {dest}")
    return dest


def main() -> int:
    print(f"Working dir: {Path.cwd()}")
    print(f"INPUT_DIR: {INPUT_DIR.resolve()}")
    print(f"Patched API dir: {PATCHED_DIR.resolve()}")
    print(f"Audio workflow: {WORKFLOW_FILE}")
    print(f"No-audio workflow: {WORKFLOW_NO_AUDIO}")
    print(f"Queue dir: {QUEUE_DIR.resolve()}")
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    COMPLETED_DIR.mkdir(parents=True, exist_ok=True)
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    FINAL_OUT.mkdir(parents=True, exist_ok=True)
    PATCHED_DIR.mkdir(parents=True, exist_ok=True)
    INPUT_DIR.mkdir(parents=True, exist_ok=True)

    ffmpeg, ffprobe = require_ffmpeg()
    base_prompt_audio = load_workflow(WORKFLOW_FILE)
    if not is_api_prompt(base_prompt_audio):
        print("WORKFLOW_FILE must be API-format JSON:", WORKFLOW_FILE)
        return 1

    base_prompt_noaudio = None
    try:
        base_prompt_noaudio = load_workflow(WORKFLOW_NO_AUDIO)
        if not is_api_prompt(base_prompt_noaudio):
            print("WARNING:", WORKFLOW_NO_AUDIO, "is not API-format")
            base_prompt_noaudio = None
        else:
            print("No-audio workflow loaded OK")
    except FileNotFoundError:
        print(f"WARNING: {WORKFLOW_NO_AUDIO} not found")

    print("Queue worker started…")
    while True:
        if not comfy_up():
            print(f"ComfyUI not reachable at {COMFY_URL} — retry in {QUEUE_POLL_SECONDS}s")
            time.sleep(QUEUE_POLL_SECONDS)
            continue
        pending = list_pending_zips()
        if not pending:
            print(f"No zips in queue/ — sleeping {QUEUE_POLL_SECONDS}s …")
            time.sleep(QUEUE_POLL_SECONDS)
            continue
        zip_path = pending[0]
        try:
            final = process_zip(zip_path, base_prompt_audio, base_prompt_noaudio, ffmpeg, ffprobe)
            move_to_completed(zip_path)
            print(f"JOB OK → {final}")
        except Exception as e:
            print(f"JOB FAILED for {zip_path.name}: {e}")
            fail_dir = QUEUE_DIR / "failed"
            fail_dir.mkdir(parents=True, exist_ok=True)
            try:
                dest = fail_dir / zip_path.name
                if dest.exists():
                    dest = fail_dir / f"{zip_path.stem}_{time.strftime('%Y%m%d_%H%M%S')}{zip_path.suffix}"
                shutil.move(str(zip_path), str(dest))
                print(f"Moved failed zip → {dest}")
            except Exception as move_err:
                print(f"Could not move failed zip: {move_err}")
                time.sleep(QUEUE_POLL_SECONDS)
        time.sleep(2)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nStopped by user.")
        sys.exit(0)
    except subprocess.CalledProcessError as e:
        print("ffmpeg failed:", e)
        err = e.stderr
        if err:
            print(err.decode(errors="replace") if isinstance(err, bytes) else err)
        sys.exit(1)
    except Exception as e:
        print("FAILED:", e)
        sys.exit(1)