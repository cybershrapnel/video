"""
check.py / checker_ltx_idle.py — hive fetcher + upscale/upload + complete + LTX idle auto-gen

When queue is empty AND no pending finals:
  start headless LTX → generate prompts (ltx_prompt_data + optional Ollama)
  while generating, keep polling the hive every POLL_DURING_GEN seconds
  if a job is claimed or a zip appears → hard-kill LTX, wait CLEAR_WAIT, resume swarm

Requires ltx_prompt_data.py beside this script (or on PYTHONPATH).

Server filters via process.php?max_seconds=&accept_audio=&client_version=
"""
from __future__ import annotations

import json
import os
import random
import re
import signal
import ssl
import subprocess
import sys
import threading
import time
import uuid
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from ltx_prompt_data import (
    ADDITIONAL_ITEMS,
    BABEL_TOPICS,
    BASE_PROMPT,
    EVE_DESC,
    REFERENCE_VARIANTS,
    SCENE_VARIANTS,
    STYLE_VARIANTS,
)

# ══════════════════════════════════════════════════════════
# EASY FLAGS — edit these per machine
# ══════════════════════════════════════════════════════════
MAX_SECONDS = 45  # main PC: 45 | 3060 short: 5
ACCEPT_AUDIO = True  # main PC: True | 3060 short: False
# Must match process.php PROTOCOL_VERSION
CLIENT_VERSION = "2"
# Optional identity (logged on server into the claimed job folder)
# Prefer an email for WORKER_ID so the operator can contact you; any name is fine.
WORKER_ID = "cybershrapnel"  # e.g. "you@example.com"
NCZ_ADDRESS = "NcUY5tNtyRvCLPJNzMazSaXmYkcg1QXjZC"  # NanoCheeZe payout address (optional)

# LTX idle (set ENABLE_LTX_IDLE=0 to disable)
ENABLE_LTX_IDLE = os.environ.get("ENABLE_LTX_IDLE", "1").strip().lower() not in (
    "0", "false", "no", "off",
)
LTX_AUTH_TOKEN = os.environ.get("LTX_AUTH_TOKEN", "swarm-idle-secret")
LTX_PORT = int(os.environ.get("LTX_PORT", "8765"))
LTX_PYTHON = os.environ.get(
    "LTX_PYTHON",
    str(Path(os.environ.get("LOCALAPPDATA", "")) / "LTXDesktop" / "python" / "python.exe"),
)
LTX_BACKEND = os.environ.get(
    "LTX_BACKEND",
    r"C:\Program Files\LTX Desktop\resources\backend",
)
LTX_APP_DATA = os.environ.get(
    "LTX_APP_DATA",
    str(Path(os.environ.get("LOCALAPPDATA", "")) / "LTXDesktop"),
)
LTX_MODEL = os.environ.get("LTX_MODEL", "fast")
LTX_RESOLUTION = os.environ.get("LTX_RESOLUTION", "720p")
LTX_DURATION = int(os.environ.get("LTX_DURATION", "10"))
LTX_FPS = int(os.environ.get("LTX_FPS", "24"))
LTX_NEG = os.environ.get(
    "LTX_NEG",
    "cartoon, 3d render, photorealistic, blurry, low quality, watermark",
)
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/generate")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "deepseek-r1:8b")
CLEAR_WAIT = float(os.environ.get("CLEAR_WAIT", "10"))
POLL_DURING_GEN = float(os.environ.get("POLL_DURING_GEN", "20"))
HEALTH_TIMEOUT = int(os.environ.get("LTX_HEALTH_TIMEOUT", "180"))
GEN_TIMEOUT = int(os.environ.get("LTX_GEN_TIMEOUT", "3600"))
# ══════════════════════════════════════════════════════════
if os.environ.get("MAX_SECONDS"):
    MAX_SECONDS = int(os.environ["MAX_SECONDS"])
if os.environ.get("ACCEPT_AUDIO") is not None:
    ACCEPT_AUDIO = os.environ.get("ACCEPT_AUDIO", "").strip().lower() in (
        "1", "true", "yes", "on"
    )
if os.environ.get("CLIENT_VERSION"):
    CLIENT_VERSION = os.environ["CLIENT_VERSION"].strip()
if os.environ.get("WORKER_ID") is not None:
    WORKER_ID = os.environ.get("WORKER_ID", "").strip()
if os.environ.get("NCZ_ADDRESS") is not None:
    NCZ_ADDRESS = os.environ.get("NCZ_ADDRESS", "").strip()

PROCESS_URL = os.environ.get(
    "PROCESS_URL",
    "https://xtdevelopment.net/video-gen/process.php",
)
COMPLETE_URL = os.environ.get("COMPLETE_URL", PROCESS_URL)
UPLOAD_URL = os.environ.get(
    "UPLOAD_URL",
    "https://xtdevelopment.net/video-gen/upload.php",
)
# Separate text2video hive (720p×10s / 1080p×5s)
T2V_PROCESS_URL = os.environ.get(
    "T2V_PROCESS_URL",
    "https://xtdevelopment.net/video-gen/process_t2v.php",
)
T2V_UPLOAD_URL = os.environ.get(
    "T2V_UPLOAD_URL",
    "https://xtdevelopment.net/video-gen/upload_t2v.php",
)
T2V_COMPLETE_URL = os.environ.get("T2V_COMPLETE_URL", T2V_PROCESS_URL)
ENABLE_T2V = os.environ.get("ENABLE_T2V", "1").strip().lower() not in (
    "0", "false", "no", "off",
)
QUEUE_DIR = Path(os.environ.get("QUEUE_DIR", "queue"))
FINAL_OUT = Path(os.environ.get("FINAL_OUT", "output_concat"))
UPSCALED_DIR = FINAL_OUT / "upscaled"
T2V_OUT = Path(os.environ.get("T2V_OUT", "t2v_out"))
T2V_UPSCALED = T2V_OUT / "upscaled"
AUTOS_DIR = Path(os.environ.get("AUTOS_DIR", "autos"))
COMFY_URL = os.environ.get("COMFY_URL", "http://127.0.0.1:8188").rstrip("/")
COMFY_CHECK_TIMEOUT = float(os.environ.get("COMFY_CHECK_TIMEOUT", "4"))
EMPTY_WAIT = int(os.environ.get("EMPTY_WAIT", "30"))
BUSY_WAIT = int(os.environ.get("BUSY_WAIT", "15"))
UPGRADE_WAIT = int(os.environ.get("UPGRADE_WAIT", "120"))
REQUEST_TIMEOUT = int(os.environ.get("REQUEST_TIMEOUT", "600"))
CHUNK_SIZE = int(os.environ.get("UPLOAD_CHUNK_SIZE", str(8 * 1024 * 1024)))
SINGLE_MAX = int(os.environ.get("UPLOAD_SINGLE_MAX", str(100 * 1024 * 1024)))
UPLOAD_FAIL_WAIT = int(os.environ.get("UPLOAD_FAIL_WAIT", "60"))
CHUNK_RETRIES = int(os.environ.get("CHUNK_RETRIES", "555"))
CHUNK_RETRY_WAIT = int(os.environ.get("CHUNK_RETRY_WAIT", "25"))
SSL_CTX = ssl._create_unverified_context()

_ltx_proc: subprocess.Popen | None = None


def ensure_dirs() -> None:
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    FINAL_OUT.mkdir(parents=True, exist_ok=True)
    UPSCALED_DIR.mkdir(parents=True, exist_ok=True)
    T2V_OUT.mkdir(parents=True, exist_ok=True)
    T2V_UPSCALED.mkdir(parents=True, exist_ok=True)
    AUTOS_DIR.mkdir(parents=True, exist_ok=True)


def which(cmd: str) -> str | None:
    from shutil import which as _which

    return _which(cmd)


def require_ffmpeg() -> str:
    ff = which("ffmpeg")
    if not ff:
        raise RuntimeError("ffmpeg not on PATH")
    return ff


def local_zips() -> list[Path]:
    if not QUEUE_DIR.is_dir():
        return []
    return sorted(
        [p for p in QUEUE_DIR.iterdir() if p.is_file() and p.suffix.lower() == ".zip"],
        key=lambda p: p.stat().st_mtime,
    )


def job_name_from_final(path: Path) -> str:
    stem = path.stem
    low = stem.lower()
    idx = low.find("_final_")
    if idx > 0:
        return stem[:idx]
    return stem


def uploaded_marker(job_name: str) -> Path:
    return UPSCALED_DIR / f".uploaded_{job_name}"


def is_uploaded(job_name: str) -> bool:
    return uploaded_marker(job_name).is_file()


def mark_uploaded(job_name: str) -> None:
    uploaded_marker(job_name).write_text(
        time.strftime("%Y-%m-%d %H:%M:%S") + "\n",
        encoding="utf-8",
    )


def progress_path(job_name: str) -> Path:
    return UPSCALED_DIR / f".upload_progress_{job_name}.json"


def load_progress(job_name: str) -> dict:
    p = progress_path(job_name)
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_progress(job_name: str, data: dict) -> None:
    progress_path(job_name).write_text(json.dumps(data, indent=2), encoding="utf-8")


def clear_progress(job_name: str) -> None:
    p = progress_path(job_name)
    if p.is_file():
        p.unlink()


def list_pending_finals() -> list[tuple[str, Path]]:
    if not FINAL_OUT.is_dir():
        return []
    by_job: dict[str, Path] = {}
    for p in FINAL_OUT.glob("*.mp4"):
        if not p.is_file() or "_final_" not in p.name.lower():
            continue
        try:
            if p.parent.resolve() == UPSCALED_DIR.resolve():
                continue
        except Exception:
            pass
        job = job_name_from_final(p)
        if not job:
            continue
        prev = by_job.get(job)
        if prev is None or p.stat().st_mtime > prev.stat().st_mtime:
            by_job[job] = p
    pending = []
    for job, path in sorted(by_job.items(), key=lambda kv: kv[1].stat().st_mtime):
        if is_uploaded(job):
            continue
        pending.append((job, path))
    return pending


def upscale_1080_cpu(src: Path, dst: Path, ffmpeg: str) -> Path:
    dst.parent.mkdir(parents=True, exist_ok=True)
    print(f"CPU upscale 1080p:\n in={src}\n out={dst}")
    subprocess.run(
        [
            ffmpeg,
            "-y",
            "-i",
            str(src),
            "-vf",
            "scale=-2:1080",
            "-c:v",
            "libx264",
            "-preset",
            "medium",
            "-crf",
            "18",
            "-c:a",
            "copy",
            "-movflags",
            "+faststart",
            str(dst),
        ],
        check=True,
        capture_output=True,
    )
    return dst


def _multipart(
    fields: dict[str, str],
    file_field: str,
    filename: str,
    file_bytes: bytes,
) -> tuple[str, bytes]:
    boundary = f"----ltx{uuid.uuid4().hex}"
    data = bytearray()
    for name, value in fields.items():
        data.extend(f"--{boundary}\r\n".encode())
        data.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        data.extend(value.encode("utf-8"))
        data.extend(b"\r\n")
    data.extend(f"--{boundary}\r\n".encode())
    data.extend(
        f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\n'.encode()
    )
    data.extend(b"Content-Type: application/octet-stream\r\n\r\n")
    data.extend(file_bytes)
    data.extend(b"\r\n")
    data.extend(f"--{boundary}--\r\n".encode())
    return boundary, bytes(data)


def _post_multipart(boundary: str, body: bytes, timeout: int | None = None) -> str:
    req = urllib.request.Request(
        UPLOAD_URL,
        data=body,
        headers={
            "User-Agent": "ltx-job-uploader/1.6",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    with urllib.request.urlopen(
        req, timeout=timeout or REQUEST_TIMEOUT, context=SSL_CTX
    ) as resp:
        return resp.read().decode("utf-8", errors="replace")


def server_upload_status(job_name: str) -> dict:
    try:
        data = urllib.parse.urlencode(
            {
                "job_name": job_name,
                "action": "status",
                "client_version": CLIENT_VERSION,
            }
        ).encode("utf-8")
        req = urllib.request.Request(
            UPLOAD_URL,
            data=data,
            headers={
                "User-Agent": "ltx-job-uploader/1.6",
                "Content-Type": "application/x-www-form-urlencoded",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as e:
        print(f" status check failed: {e}")
        return {}


def complete_job_on_server(job_name: str) -> bool:
    data = urllib.parse.urlencode(
        {
            "action": "complete",
            "job_name": job_name,
            "client_version": CLIENT_VERSION,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        COMPLETE_URL,
        data=data,
        headers={
            "User-Agent": "ltx-job-uploader/1.6",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        if text.strip() == "SERVER_UPDATED_CHECKER_MUST_UPDATE":
            print("*** complete blocked: SERVER PROTOCOL UPDATED — update checker ***")
            return False
        print(f" complete {job_name}: {text}")
        try:
            return bool(json.loads(text).get("ok"))
        except Exception:
            return "ok" in text.lower()
    except urllib.error.HTTPError as e:
        if e.code == 426:
            print("*** complete blocked: HTTP 426 upgrade required ***")
            return False
        print(f" complete failed for {job_name}: HTTP {e.code}")
        return False
    except Exception as e:
        print(f" complete failed for {job_name}: {e}")
        return False


def _upload_single(mp4: Path, job_name: str) -> None:
    boundary, body = _multipart(
        {"job_name": job_name},
        "file",
        mp4.name,
        mp4.read_bytes(),
    )
    text = _post_multipart(boundary, body)
    print(f"Upload response: {text}")
    if '"ok":false' in text.replace(" ", "").lower():
        raise RuntimeError(f"upload rejected: {text}")


def _upload_chunk_once(
    piece: bytes,
    job_name: str,
    filename: str,
    index: int,
    total: int,
    resume: bool,
) -> dict:
    fields = {
        "job_name": job_name,
        "filename": filename,
        "chunk_index": str(index),
        "total_chunks": str(total),
        "chunk_size": str(CHUNK_SIZE),
    }
    if resume or index > 0:
        fields["resume"] = "1"
    boundary, body = _multipart(fields, "file", f"{filename}.part{index}", piece)
    text = _post_multipart(boundary, body)
    print(f" chunk {index + 1}/{total} response: {text}")
    try:
        obj = json.loads(text)
    except Exception:
        raise RuntimeError(f"bad json: {text}")
    if not obj.get("ok"):
        raise RuntimeError(f"chunk {index} rejected: {text}")
    return obj


def _upload_chunk_with_retries(
    piece: bytes,
    job_name: str,
    filename: str,
    index: int,
    total: int,
    resume: bool,
) -> dict:
    last_err: Exception | None = None
    for attempt in range(1, CHUNK_RETRIES + 1):
        try:
            return _upload_chunk_once(piece, job_name, filename, index, total, resume)
        except Exception as e:
            last_err = e
            print(f" chunk {index + 1}/{total} attempt {attempt}/{CHUNK_RETRIES} failed: {e}")
            if attempt < CHUNK_RETRIES:
                time.sleep(CHUNK_RETRY_WAIT * attempt)
    raise RuntimeError(f"chunk {index} failed after {CHUNK_RETRIES} tries: {last_err}")


def upload_final(mp4: Path, job_name: str) -> None:
    size = mp4.stat().st_size
    if size <= SINGLE_MAX:
        print(f"Uploading (single) {mp4.name} ({size} bytes) job={job_name}")
        _upload_single(mp4, job_name)
        clear_progress(job_name)
        return
    total = (size + CHUNK_SIZE - 1) // CHUNK_SIZE
    prog = load_progress(job_name)
    start = int(prog.get("next_chunk", 0)) if prog.get("filename") == mp4.name else 0
    st = server_upload_status(job_name)
    part_bytes = int(st.get("part_bytes") or 0)
    if part_bytes > 0:
        server_next = part_bytes // CHUNK_SIZE
        if part_bytes % CHUNK_SIZE == 0 and server_next <= total:
            if server_next > start:
                start = server_next
            print(f" server has {part_bytes} bytes → resume chunk index {start}")
    if start >= total:
        start = 0
        print(" progress past end — restarting upload")
    print(
        f"Uploading (chunked) {mp4.name} ({size} bytes) "
        f"in {total} chunks; resuming at {start + 1}/{total}"
    )
    with mp4.open("rb") as f:
        if start > 0:
            f.seek(start * CHUNK_SIZE)
        for idx in range(start, total):
            piece = f.read(CHUNK_SIZE)
            if not piece:
                break
            print(f" sending chunk {idx + 1}/{total} ({len(piece)} bytes) …")
            resume = idx > 0 or start > 0
            _upload_chunk_with_retries(piece, job_name, mp4.name, idx, total, resume)
            save_progress(
                job_name,
                {
                    "filename": mp4.name,
                    "next_chunk": idx + 1,
                    "total_chunks": total,
                    "chunk_size": CHUNK_SIZE,
                    "updated": time.strftime("%Y-%m-%d %H:%M:%S"),
                },
            )
    clear_progress(job_name)
    print(f"Chunked upload complete for {job_name}")


def postprocess_pending(ffmpeg: str) -> int:
    pending = list_pending_finals()
    if not pending:
        print("No pending finals to upscale/upload")
        return 0
    # Never leave LTX running while we still owe the hive an upload
    if ltx_alive() or (_ltx_proc is not None and _ltx_proc.poll() is None):
        print("Pending finals exist — stopping LTX before upscale/upload")
        stop_ltx()
    print(f"Pending finals: {len(pending)}")
    done = 0
    for job_name, src in pending:
        try:
            if is_uploaded(job_name):
                if not complete_job_on_server(job_name):
                    print(f" retry complete still failing for {job_name}")
                continue
            print(f"Postprocess '{job_name}': {src.name}")
            dst = UPSCALED_DIR / f"{src.stem}_1080p.mp4"
            if dst.is_file() and dst.stat().st_mtime >= src.stat().st_mtime:
                print(f" already upscaled: {dst.name}")
            else:
                upscale_1080_cpu(src, dst, ffmpeg)
            upload_final(dst, job_name)
            mark_uploaded(job_name)
            if not complete_job_on_server(job_name):
                print(
                    f" WARNING: upload OK but server complete failed for {job_name} "
                    f"(will retry complete on later loops)"
                )
            else:
                print(f" done + completed on server: {job_name}")
            done += 1
        except subprocess.CalledProcessError as e:
            err = e.stderr
            if isinstance(err, bytes):
                err = err.decode(errors="replace")
            print(f" ffmpeg failed for {job_name}: {e}\n{err}")
            print(f" will retry later (sleep {UPLOAD_FAIL_WAIT}s)")
            time.sleep(UPLOAD_FAIL_WAIT)
        except Exception as e:
            print(f" failed for {job_name}: {e}")
            print(f" progress saved — will resume later (sleep {UPLOAD_FAIL_WAIT}s)")
            time.sleep(UPLOAD_FAIL_WAIT)
    return done


def claim_url() -> str:
    params: dict[str, str] = {
        "max_seconds": str(int(MAX_SECONDS)),
        "accept_audio": "1" if ACCEPT_AUDIO else "0",
        "client_version": CLIENT_VERSION,
    }
    # Optional identity — server logs into the claimed job folder
    if WORKER_ID:
        params["worker_id"] = WORKER_ID
    if NCZ_ADDRESS:
        params["ncz_address"] = NCZ_ADDRESS
    q = urllib.parse.urlencode(params)
    sep = "&" if "?" in PROCESS_URL else "?"
    return PROCESS_URL + sep + q


def fetch_once() -> str:
    url = claim_url()
    print(f"Claim URL: {url}")
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "ltx-job-fetcher/1.6",
            "Accept": "application/zip,*/*",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            ctype = (resp.headers.get("Content-Type") or "").lower()
            disp = resp.headers.get("Content-Disposition") or ""
            job_status = resp.headers.get("X-Job-Status") or ""
            need_ver = resp.headers.get("X-Protocol-Version") or "?"
            body = resp.read()
            if (
                status == 426
                or job_status == "upgrade"
                or body.strip() == b"SERVER_UPDATED_CHECKER_MUST_UPDATE"
            ):
                print(
                    "*** SERVER PROTOCOL UPDATED ***\n"
                    f" this checker: {CLIENT_VERSION}\n"
                    f" server wants: {need_ver}\n"
                    " Update check.py (CLIENT_VERSION) / scripts, restart.\n"
                    " Not claiming jobs until versions match."
                )
                return "upgrade"
            if status == 204 or job_status == "empty" or body.strip() == b"NO_JOB":
                print(
                    f"No matching job (max_seconds={MAX_SECONDS}, "
                    f"accept_audio={int(ACCEPT_AUDIO)}, version={CLIENT_VERSION})."
                )
                return "empty"
            if status == 409 or job_status == "race" or body.strip() == b"CLAIM_RACE":
                print("Claim race (another worker took it) — retry soon.")
                return "race"
            if status != 200:
                print(f"Unexpected HTTP {status}: {body[:200]!r}")
                return "error"
            filename = "job.zip"
            if "filename=" in disp:
                part = disp.split("filename=", 1)[1].strip().strip('"')
                if part:
                    filename = os.path.basename(part)
            if "zip" not in ctype and not filename.lower().endswith(".zip"):
                if not body.startswith(b"PK"):
                    text = body[:80].decode("utf-8", errors="replace")
                    print(f"Not a zip: {text!r}")
                    if "SERVER_UPDATED_CHECKER_MUST_UPDATE" in text:
                        return "upgrade"
                    if "NO_JOB" in text:
                        return "empty"
                    if "CLAIM_RACE" in text:
                        return "race"
                    return "error"
            dest = QUEUE_DIR / filename
            if dest.exists():
                dest = QUEUE_DIR / f"{dest.stem}_{int(time.time())}.zip"
            dest.write_bytes(body)
            print(f"Saved {dest} ({len(body)} bytes)")
            return "saved"
    except urllib.error.HTTPError as e:
        if e.code == 426:
            need = e.headers.get("X-Protocol-Version") if e.headers else "?"
            print(
                "*** SERVER PROTOCOL UPDATED (HTTP 426) ***\n"
                f" this checker: {CLIENT_VERSION}\n"
                f" server wants: {need}\n"
                " Update scripts and restart."
            )
            return "upgrade"
        if e.code == 204:
            print("No matching job (204).")
            return "empty"
        if e.code == 409:
            print("Claim race (409).")
            return "race"
        try:
            err_body = e.read()[:200]
        except Exception:
            err_body = b""
        print(f"HTTPError {e.code}: {err_body!r}")
        return "error"
    except urllib.error.URLError as e:
        print(f"URLError: {e}")
        return "error"
    except Exception as e:
        print(f"Error: {e}")
        return "error"


# ══════════════════════════════════════════════════════════
# LTX idle + Ollama (uses ltx_prompt_data.py)
# ══════════════════════════════════════════════════════════
def banner(title: str) -> None:
    line = "=" * 72
    print(f"\n{line}\n  {title}\n{line}")
    sys.stdout.flush()


def log_block(label: str, text: str) -> None:
    print(f"\n----- BEGIN {label} ({len(text)} chars) -----")
    print(text)
    print(f"----- END {label} -----\n")
    sys.stdout.flush()


def http_json(
    url: str,
    method: str = "GET",
    body: dict | None = None,
    headers: dict | None = None,
    timeout: float = 60,
):
    data = None
    hdrs = dict(headers or {})
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        hdrs.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=data, headers=hdrs, method=method)
    with urllib.request.urlopen(req, timeout=timeout, context=SSL_CTX) as resp:
        raw = resp.read().decode("utf-8", errors="replace")
        if not raw:
            return resp.status, None, dict(resp.headers)
        try:
            return resp.status, json.loads(raw), dict(resp.headers)
        except Exception:
            return resp.status, raw, dict(resp.headers)


def ltx_base() -> str:
    return f"http://127.0.0.1:{LTX_PORT}"


def ltx_headers() -> dict:
    return {
        "Authorization": f"Bearer {LTX_AUTH_TOKEN}",
        "Content-Type": "application/json",
    }


def ltx_alive() -> bool:
    try:
        status, _, _ = http_json(
            ltx_base() + "/health",
            headers=ltx_headers(),
            timeout=5,
        )
        return status == 200
    except Exception:
        return False



def ltx_installed() -> bool:
    """True if LTX Desktop python + backend exist on this machine."""
    py = Path(LTX_PYTHON)
    server = Path(LTX_BACKEND) / "ltx2_server.py"
    ok = py.is_file() and server.is_file()
    if not ok:
        print("LTX Desktop NOT installed / not found:")
        print(f"  LTX_PYTHON  = {py}  exists={py.is_file()}")
        print(f"  LTX_BACKEND = {LTX_BACKEND}")
        print(f"  ltx2_server = {server}  exists={server.is_file()}")
    return ok


def comfyui_alive() -> bool:
    """True if local ComfyUI responds (needed for MAIN hive / zip jobs)."""
    for path in ("/system_stats", "/queue", "/"):
        try:
            req = urllib.request.Request(
                COMFY_URL + path,
                headers={"User-Agent": "ltx-checker/comfy-check"},
                method="GET",
            )
            with urllib.request.urlopen(
                req, timeout=COMFY_CHECK_TIMEOUT, context=SSL_CTX
            ) as resp:
                code = getattr(resp, "status", None) or resp.getcode()
                if 200 <= int(code) < 500:
                    return True
        except Exception:
            continue
    return False


def start_ltx() -> None:
    global _ltx_proc
    if ltx_alive():
        print("LTX already up")
        return
    if _ltx_proc is not None and _ltx_proc.poll() is None:
        print("LTX process still starting…")
        return

    backend = str(Path(LTX_BACKEND).resolve())
    py = LTX_PYTHON
    if not Path(py).is_file():
        raise RuntimeError(f"LTX python not found: {py}")
    if not Path(backend, "ltx2_server.py").is_file():
        raise RuntimeError(f"ltx2_server.py not found under {backend}")

    code = (
        "import sys; "
        f"sys.path.insert(0, r'{backend}'); "
        "import runpy; "
        f"runpy.run_path(r'{backend}\\ltx2_server.py', run_name='__main__')"
    )
    env = os.environ.copy()
    env["LTX_AUTH_TOKEN"] = LTX_AUTH_TOKEN
    env["LTX_PORT"] = str(LTX_PORT)
    env["LTX_APP_DATA_DIR"] = LTX_APP_DATA
    env["PYTHONUNBUFFERED"] = "1"

    print(f"Starting LTX backend on :{LTX_PORT} …")
    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]

    _ltx_proc = subprocess.Popen(
        [py, "-c", code],
        cwd=backend,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=creationflags,
    )

    t0 = time.time()
    while time.time() - t0 < HEALTH_TIMEOUT:
        if ltx_alive():
            print("LTX health OK")
            return
        if _ltx_proc.poll() is not None:
            raise RuntimeError(f"LTX exited early code={_ltx_proc.returncode}")
        time.sleep(1.5)
    raise RuntimeError("LTX failed to become healthy in time")


def stop_ltx() -> None:
    """Hard stop — fine to interrupt mid-generation."""
    global _ltx_proc
    print("Stopping LTX (hard) …")
    if _ltx_proc is not None and _ltx_proc.poll() is None:
        try:
            if sys.platform == "win32":
                _ltx_proc.send_signal(signal.CTRL_BREAK_EVENT)  # type: ignore[attr-defined]
            else:
                _ltx_proc.terminate()
        except Exception:
            pass
        try:
            _ltx_proc.kill()
        except Exception:
            pass
        try:
            _ltx_proc.wait(timeout=5)
        except Exception:
            pass
    _ltx_proc = None

    if sys.platform == "win32":
        try:
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "Get-CimInstance Win32_Process | "
                    "Where-Object { $_.CommandLine -match 'ltx2_server' } | "
                    "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }",
                ],
                capture_output=True,
                timeout=15,
            )
        except Exception as e:
            print(f"  cleanup note: {e}")
    print(f"LTX stopped — waiting {CLEAR_WAIT}s for VRAM/RAM …")
    time.sleep(CLEAR_WAIT)


def ollama_spoken(babel: str) -> tuple[str, bool]:
    ollama_prompt = (
        "Take the following concatenated text and summarize or adapt it into a "
        "single quick phrase or sentence that takes 10 seconds or less to say "
        "out loud. Return ONLY the final spoken text with no additional "
        f"commentary, quotes, or preamble:\n\n{babel}"
    )
    banner("OLLAMA REQUEST")
    print(f"model: {OLLAMA_MODEL}")
    print(f"url:   {OLLAMA_URL}")
    log_block("OLLAMA_INPUT_BABEL", babel)
    log_block("OLLAMA_FULL_PROMPT_SENT", ollama_prompt)
    try:
        body = {
            "model": OLLAMA_MODEL,
            "prompt": ollama_prompt,
            "stream": False,
        }
        status, data, _ = http_json(OLLAMA_URL, method="POST", body=body, timeout=120)
        print(f"Ollama HTTP status: {status}")
        if status == 200 and isinstance(data, dict):
            raw_response = data.get("response", "")
            if not isinstance(raw_response, str):
                raw_response = str(raw_response)
            log_block("OLLAMA_RAW_RESPONSE", raw_response)
            for k in ("model", "created_at", "done", "total_duration", "eval_count"):
                if k in data:
                    print(f"  ollama.{k} = {data[k]}")
            text = re.sub(r"<think>[\s\S]*?</think>", "", raw_response, flags=re.I).strip()
            text = text.strip("\"'")
            log_block("OLLAMA_CLEANED_SPOKEN", text)
            if text:
                return text, True
            print("Ollama returned empty after cleanup — using babel fallback")
        else:
            log_block("OLLAMA_UNEXPECTED_BODY", repr(data))
    except Exception as e:
        print(f"Ollama error (fallback to raw babel): {e!r}")
        sys.stdout.flush()
    return babel, False


def generate_dynamic_prompt() -> tuple[str, bool]:
    include_eve = random.random() < 0.5
    eve = EVE_DESC if include_eve else ""
    scene = random.choice(SCENE_VARIANTS)
    style = random.choice(STYLE_VARIANTS)
    reference = random.choice(REFERENCE_VARIANTS)

    n_babel = random.randint(1, min(10, len(BABEL_TOPICS)))
    chosen_babel = random.sample(BABEL_TOPICS, n_babel)
    babel = " ".join(chosen_babel)

    banner("PROMPT ASSEMBLY")
    print(f"include_eve = {include_eve}")
    print(f"n_babel     = {n_babel}")
    log_block("CHOSEN_SCENE", scene)
    log_block("CHOSEN_STYLE", style)
    log_block("CHOSEN_REFERENCE", reference)
    log_block("CHOSEN_BABEL_TOPICS", "\n".join(f"  - {b}" for b in chosen_babel))

    spoken, used_ollama = ollama_spoken(babel)

    n_items = random.randint(1, min(13, len(ADDITIONAL_ITEMS)))
    items = random.sample(ADDITIONAL_ITEMS, n_items)
    log_block("CHOSEN_ADDITIONAL_ITEMS", "\n".join(f"  - {x}" for x in items))

    prompt = (
        f"{BASE_PROMPT} {eve}{scene} {style} {reference}. "
        f'spoken audio should be some variation of this text "{spoken}", '
        f"{', '.join(items)}, Style: cel-shaded 2D anime, clean linework."
    )
    banner("FINAL LTX PROMPT")
    print(f"used_ollama = {used_ollama}")
    print(f"prompt_len  = {len(prompt)}")
    log_block("FULL_PROMPT_TO_LTX", prompt)
    return prompt, used_ollama


# ══════════════════════════════════════════════════════════
# Text2video queue — process_t2v.php (720p×10 / 1080p×5)
# Runs UNINTERRUPTED (no main-hive poll while generating)
# ══════════════════════════════════════════════════════════
def t2v_claim_url() -> str:
    params: dict[str, str] = {"client_version": CLIENT_VERSION}
    if WORKER_ID:
        params["worker_id"] = WORKER_ID
    if NCZ_ADDRESS:
        params["ncz_address"] = NCZ_ADDRESS
    q = urllib.parse.urlencode(params)
    sep = "&" if "?" in T2V_PROCESS_URL else "?"
    return T2V_PROCESS_URL + sep + q


def fetch_t2v_once() -> dict | str:
    """
    Claim one T2V job.
    Success → dict including optional start_frame fields from server RAW JSON.
    Else → 'empty' | 'race' | 'upgrade' | 'error'
    """
    url = t2v_claim_url()
    print(f"T2V Claim URL: {url}")
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "ltx-t2v-fetcher/1.0", "Accept": "application/json,*/*"},
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            job_status = resp.headers.get("X-Job-Status") or ""
            body = resp.read()
            if status == 204 or job_status == "empty" or body.strip() in (b"NO_JOB", b""):
                print("No T2V job available.")
                return "empty"
            if status == 409 or job_status == "race":
                return "race"
            if status == 426 or job_status == "upgrade":
                return "upgrade"
            if status != 200:
                print(f"T2V unexpected HTTP {status}: {body[:200]!r}")
                return "error"
            raw_text = body.decode("utf-8", errors="replace")
            # Always show the REAL server claim JSON (not a doctored summary)
            log_block("T2V_CLAIM_RAW_JSON", raw_text)
            try:
                obj = json.loads(raw_text)
            except Exception:
                print(f"T2V bad JSON: {body[:200]!r}")
                return "error"
            if not obj.get("ok") and not obj.get("job_name"):
                if obj.get("status") == "empty":
                    return "empty"
                print(f"T2V reject: {obj}")
                return "error"
            job_name = str(obj.get("job_name") or "").strip()
            prompt = str(obj.get("prompt") or obj.get("promp") or "").strip()
            if not job_name or not prompt:
                print(f"T2V missing job_name/prompt: {obj}")
                return "error"
            res = str(obj.get("resolution") or "720p").strip().lower()
            if res not in ("720p", "1080p"):
                res = "720p"
            # Prefer server duration; allow 5/10/20 with valid pairs
            try:
                duration = int(obj.get("duration") or 0)
            except Exception:
                duration = 0
            allowed = {
                (5, "1080p"),
                (8, "1080p"),
                (10, "720p"),
                (10, "1080p"),
                (20, "720p"),
            }
            if (duration, res) not in allowed:
                # soft fallback
                if res == "1080p":
                    duration = 5
                else:
                    res = "720p"
                    duration = 10
            negative = str(obj.get("negative") or obj.get("anti") or LTX_NEG).strip()
            has_sf = bool(obj.get("has_start_frame"))
            sf_name = str(obj.get("start_frame") or "").strip()
            sf_url = str(obj.get("start_frame_url") or "").strip()
            job = {
                "job_name": job_name,
                "prompt": prompt,
                "negative": negative or LTX_NEG,
                "resolution": res,
                "duration": duration,
                "has_start_frame": has_sf,
                "start_frame": sf_name,
                "start_frame_url": sf_url,
            }
            print(
                f"T2V claimed {job_name}: {res} × {duration}s "
                f"(prompt {len(prompt)} chars, start_frame={has_sf})"
            )
            if has_sf:
                print(f"  start_frame={sf_name!r}")
                print(f"  start_frame_url={sf_url!r}")
            return job
    except urllib.error.HTTPError as e:
        if e.code == 204:
            return "empty"
        if e.code == 409:
            return "race"
        if e.code == 426:
            return "upgrade"
        print(f"T2V HTTPError {e.code}")
        return "error"
    except Exception as e:
        print(f"T2V fetch error: {e}")
        return "error"


def ltx_outputs_dir() -> Path:
    return Path(LTX_APP_DATA) / "outputs"


def newest_mp4_after(dir_path: Path, since_mtime: float) -> Path | None:
    if not dir_path.is_dir():
        return None
    best: Path | None = None
    best_m = since_mtime
    for p in dir_path.glob("*.mp4"):
        try:
            m = p.stat().st_mtime
        except Exception:
            continue
        if m > best_m:
            best_m = m
            best = p
    return best


def ltx_generate_blocking(
    prompt: str,
    negative: str,
    resolution: str,
    duration: int,
    tag: str = "job",
    image_path: str | Path | None = None,
) -> Path | None:
    """Synchronous LTX generate — no hive polling.

    image_path: optional local filesystem path for first-frame conditioning.
    LTX Desktop /api/generate accepts `imagePath` (local path) and treats it
    as ImageConditioningInput at frame_idx=0 (i2v).
    """
    body: dict = {
        "prompt": prompt,
        "negativePrompt": negative or LTX_NEG,
        "model": LTX_MODEL,
        "resolution": resolution,
        "duration": int(duration),
        "fps": LTX_FPS,
        "audio": True,
        "cameraMotion": "none",
        "aspectRatio": "16:9",
    }
    if image_path:
        p = str(Path(image_path).resolve())
        body["imagePath"] = p
        # also set startFramePath for forks that use that name
        body["startFramePath"] = p
    banner(f"LTX /api/generate ({tag}) {resolution}×{duration}s")
    if image_path:
        print(f"  imagePath (start frame) = {body.get('imagePath')}")
    # This is the ACTUAL JSON body posted to LTX — not a summary
    log_block("LTX_REQUEST_JSON", json.dumps(body, ensure_ascii=False, indent=2))
    out_dir = ltx_outputs_dir()
    t0 = time.time()
    try:
        status, data, _ = http_json(
            ltx_base() + "/api/generate",
            method="POST",
            body=body,
            headers=ltx_headers(),
            timeout=GEN_TIMEOUT,
        )
        print(f"LTX HTTP status: {status}")
        if isinstance(data, dict):
            log_block("LTX_RESPONSE_JSON", json.dumps(data, ensure_ascii=False, indent=2))
            for key in ("output_path", "path", "video", "file", "filename"):
                v = data.get(key)
                if isinstance(v, str) and v.lower().endswith(".mp4") and Path(v).is_file():
                    return Path(v)
        elif data is not None:
            log_block("LTX_RESPONSE_RAW", repr(data))
    except Exception as e:
        print(f"LTX generate error: {e!r}")
        sys.stdout.flush()
        return None
    found = newest_mp4_after(out_dir, t0 - 2.0)
    if found:
        print(f"LTX output file: {found}")
    else:
        print(f"WARNING: no new mp4 under {out_dir}")
    return found


def t2v_uploaded_marker(job_name: str) -> Path:
    return T2V_UPSCALED / f".uploaded_{job_name}"


def download_start_frame(job: dict) -> Path | None:
    """
    Download start_frame_url from the claim into T2V_OUT/<job>/start_frame.<ext>.
    Returns local path or None if no start frame / download failed.
    """
    if not job.get("has_start_frame"):
        return None
    url = str(job.get("start_frame_url") or "").strip()
    if not url:
        print("WARNING: has_start_frame=True but start_frame_url empty — skipping image")
        return None
    name = str(job.get("start_frame") or "start_frame.png").strip() or "start_frame.png"
    # sanitize filename
    name = Path(name).name
    job_name = str(job.get("job_name") or "t2v")
    dest_dir = T2V_OUT / "_start_frames" / job_name
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / name
    print(f"Downloading start frame:\n  url={url}\n  → {dest}")
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "ltx-t2v-fetcher/1.0"},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT, context=SSL_CTX) as resp:
            data = resp.read()
            ctype = (resp.headers.get("Content-Type") or "").lower()
        if not data or len(data) < 32:
            print(f"WARNING: start frame download too small ({len(data)} bytes)")
            return None
        # If server returned HTML error page, bail
        if data[:32].lstrip().startswith(b"<") or "text/html" in ctype:
            print(f"WARNING: start frame URL returned HTML, not an image ({ctype})")
            return None
        dest.write_bytes(data)
        print(f"Start frame saved: {dest} ({len(data)} bytes, content-type={ctype or '?'})")
        return dest
    except Exception as e:
        print(f"WARNING: start frame download failed: {e!r}")
        return None


def run_t2v_job(job: dict, ffmpeg: str) -> bool:
    """
    Generate T2V on LTX with NO interruption.
    720p → upscale 1080p → upload_t2v.php ONLY → complete on process_t2v.php

    Optional start frame: download start_frame_url → local path → imagePath on LTX.

    Upload/complete MUST succeed before returning True.
    Never touches main UPLOAD_URL / completed/ (that was the double-upload bug).
    """
    import shutil

    job_name = job["job_name"]
    prompt = job["prompt"]
    negative = job.get("negative") or LTX_NEG
    resolution = job["resolution"]
    duration = int(job["duration"])

    banner(f"T2V JOB {job_name}")
    log_block("T2V_PROMPT", prompt)
    print(f"resolution={resolution} duration={duration}")
    print(
        f"has_start_frame={job.get('has_start_frame')} "
        f"start_frame={job.get('start_frame')!r}"
    )
    if job.get("start_frame_url"):
        print(f"start_frame_url={job.get('start_frame_url')}")

    # Already uploaded this job earlier? Just force complete + done.
    if t2v_uploaded_marker(job_name).is_file():
        print(f"T2V already marked uploaded: {job_name} — ensuring server complete")
        while not _t2v_complete_with_retries(job_name):
            print(f"T2V complete still failing — sleep {UPLOAD_FAIL_WAIT}s and retry")
            time.sleep(UPLOAD_FAIL_WAIT)
        return True

    # Download optional first-frame image BEFORE starting generate
    image_path = download_start_frame(job)
    if job.get("has_start_frame") and image_path is None:
        print(
            "WARNING: job requested start frame but download failed — "
            "continuing as pure text-to-video"
        )

    start_ltx()
    src = ltx_generate_blocking(
        prompt,
        negative,
        resolution,
        duration,
        tag=f"t2v:{job_name}",
        image_path=image_path,
    )
    if src is None or not src.is_file():
        print(f"T2V generate failed for {job_name}")
        return False

    T2V_OUT.mkdir(parents=True, exist_ok=True)
    T2V_UPSCALED.mkdir(parents=True, exist_ok=True)
    local = T2V_OUT / f"{job_name}_{resolution}_{duration}s.mp4"
    try:
        shutil.move(str(src), str(local))
        print(f"T2V output moved → {local}")
    except Exception as e:
        try:
            shutil.copy2(src, local)
            print(f"T2V output copied → {local} (move failed: {e})")
        except Exception as e2:
            print(f"copy/move failed, using original: {e2}")
            local = src

    if resolution == "720p":
        dst = T2V_UPSCALED / f"{job_name}_1080p.mp4"
        while True:
            try:
                if dst.is_file() and dst.stat().st_mtime >= local.stat().st_mtime:
                    print(f"T2V already upscaled: {dst.name}")
                else:
                    upscale_1080_cpu(local, dst, ffmpeg)
                upload_path = dst
                break
            except Exception as e:
                print(f"T2V upscale failed: {e} — sleep {UPLOAD_FAIL_WAIT}s and retry")
                time.sleep(UPLOAD_FAIL_WAIT)
    else:
        upload_path = local

    # Upload ONLY to T2V_UPLOAD_URL — retry forever until success
    while True:
        try:
            _t2v_upload_file(upload_path, job_name)
            break
        except Exception as e:
            print(f"T2V upload failed: {e} — sleep {UPLOAD_FAIL_WAIT}s and retry (must succeed)")
            time.sleep(UPLOAD_FAIL_WAIT)

    # Complete on T2V server — retry forever until success
    while not _t2v_complete_with_retries(job_name):
        print(f"T2V complete failed — sleep {UPLOAD_FAIL_WAIT}s and retry (must succeed)")
        time.sleep(UPLOAD_FAIL_WAIT)

    t2v_uploaded_marker(job_name).write_text(
        time.strftime("%Y-%m-%d %H:%M:%S") + "\n", encoding="utf-8"
    )
    print(f"T2V done: {job_name}")
    return True


def _t2v_upload_file(upload_path: Path, job_name: str) -> None:
    """Single or chunked upload to T2V_UPLOAD_URL only. Raises on failure."""
    size = upload_path.stat().st_size
    print(f"T2V uploading {upload_path.name} ({size} bytes) → {T2V_UPLOAD_URL}")
    if size <= SINGLE_MAX:
        boundary, body = _multipart(
            {"job_name": job_name}, "file", upload_path.name, upload_path.read_bytes()
        )
        req = urllib.request.Request(
            T2V_UPLOAD_URL,
            data=body,
            headers={
                "User-Agent": "ltx-t2v-uploader/1.0",
                "Content-Type": f"multipart/form-data; boundary={boundary}",
            },
            method="POST",
        )
        with urllib.request.urlopen(
            req, timeout=REQUEST_TIMEOUT, context=SSL_CTX
        ) as resp:
            text = resp.read().decode("utf-8", errors="replace")
            print(f"T2V upload: {text}")
            # soft-check: if JSON says not ok, treat as failure
            try:
                obj = json.loads(text)
                if obj.get("ok") is False:
                    raise RuntimeError(f"T2V upload rejected: {text}")
            except json.JSONDecodeError:
                if "error" in text.lower() and "ok" not in text.lower():
                    raise RuntimeError(f"T2V upload bad response: {text}")
        return

    total = (size + CHUNK_SIZE - 1) // CHUNK_SIZE
    with open(upload_path, "rb") as f:
        for idx in range(total):
            piece = f.read(CHUNK_SIZE)
            # per-chunk retries
            attempt = 0
            while True:
                attempt += 1
                try:
                    fields = {
                        "job_name": job_name,
                        "filename": upload_path.name,
                        "chunk_index": str(idx),
                        "total_chunks": str(total),
                        "chunk_size": str(CHUNK_SIZE),
                    }
                    if idx > 0:
                        fields["resume"] = "1"
                    boundary, body = _multipart(
                        fields, "file", f"{upload_path.name}.part{idx}", piece
                    )
                    req = urllib.request.Request(
                        T2V_UPLOAD_URL,
                        data=body,
                        headers={
                            "User-Agent": "ltx-t2v-uploader/1.0",
                            "Content-Type": f"multipart/form-data; boundary={boundary}",
                        },
                        method="POST",
                    )
                    with urllib.request.urlopen(
                        req, timeout=REQUEST_TIMEOUT, context=SSL_CTX
                    ) as resp:
                        print(
                            f"  T2V chunk {idx+1}/{total} (try {attempt}): "
                            f"{resp.read().decode('utf-8', errors='replace')}"
                        )
                    break
                except Exception as e:
                    print(
                        f"  T2V chunk {idx+1}/{total} failed (try {attempt}): {e} "
                        f"— sleep {CHUNK_RETRY_WAIT}s"
                    )
                    time.sleep(CHUNK_RETRY_WAIT)


def _t2v_complete_with_retries(job_name: str) -> bool:
    """POST action=complete to T2V_COMPLETE_URL. Returns True on success."""
    data = urllib.parse.urlencode(
        {
            "action": "complete",
            "job_name": job_name,
            "client_version": CLIENT_VERSION,
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        T2V_COMPLETE_URL,
        data=data,
        headers={
            "User-Agent": "ltx-t2v-uploader/1.0",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60, context=SSL_CTX) as resp:
            text = resp.read().decode("utf-8", errors="replace")
        print(f"T2V complete: {text}")
        try:
            return bool(json.loads(text).get("ok"))
        except Exception:
            return "ok" in text.lower() or text.strip() in ("OK", "COMPLETE", "1")
    except Exception as e:
        print(f"T2V complete error: {e}")
        return False


def save_idle_to_autos(src: Path | None) -> Path | None:
    """Copy/move an idle auto-gen mp4 into ./autos/ so it is not mixed with jobs."""
    if src is None or not src.is_file():
        return None
    import shutil

    AUTOS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    dest = AUTOS_DIR / f"auto_{stamp}_{src.name}"
    try:
        shutil.move(str(src), str(dest))
        print(f"Idle auto-gen moved → {dest}")
        return dest
    except Exception as e:
        try:
            shutil.copy2(src, dest)
            print(f"Idle auto-gen copied → {dest} (move failed: {e})")
            return dest
        except Exception as e2:
            print(f"WARNING: could not save idle gen to autos/: {e2}")
            return src


def ltx_generate_one_blocking() -> Path | None:
    prompt, used_ollama = generate_dynamic_prompt()
    tag = "Ollama" if used_ollama else "fallback-babel"
    src = ltx_generate_blocking(
        prompt, LTX_NEG, LTX_RESOLUTION, LTX_DURATION, tag=f"idle:{tag}"
    )
    return save_idle_to_autos(src)


def ltx_generate_while_polling() -> str:
    """
    Run one LTX gen on a background thread.
    Main thread keeps calling fetch_once() every POLL_DURING_GEN seconds.
    Returns: done | saved | upgrade | error
    """
    gen_err: list[BaseException] = []

    def _runner() -> None:
        try:
            ltx_generate_one_blocking()
        except BaseException as e:  # noqa: BLE001
            gen_err.append(e)

    t = threading.Thread(target=_runner, name="ltx-generate", daemon=True)
    t.start()
    print(
        f"Idle LTX gen running — MAIN hive poll every {POLL_DURING_GEN}s "
        f"(T2V queue paused until this gen ends)"
    )

    while t.is_alive():
        if local_zips():
            print("Zip appeared in queue/ during idle LTX — killing LTX")
            stop_ltx()
            t.join(timeout=5)
            return "saved"

        print("[during idle LTX] checking MAIN hive for zip jobs …")
        result = fetch_once()
        if result == "saved":
            print("Main hive job claimed during idle LTX — killing LTX")
            stop_ltx()
            t.join(timeout=5)
            return "saved"
        if result == "upgrade":
            print("Protocol upgrade required — killing LTX")
            stop_ltx()
            t.join(timeout=5)
            return "upgrade"
        if result == "race":
            time.sleep(3)
            continue

        waited = 0.0
        while waited < POLL_DURING_GEN and t.is_alive():
            if local_zips():
                print("Zip appeared in queue/ during LTX gen — killing LTX")
                stop_ltx()
                t.join(timeout=5)
                return "saved"
            time.sleep(min(2.0, POLL_DURING_GEN - waited))
            waited += 2.0

    if gen_err:
        print(f"LTX gen thread error: {gen_err[0]!r}")
        return "error"
    print("LTX generation finished (no hive job interrupted it)")
    return "done"


def main() -> int:
    global ENABLE_LTX_IDLE, ENABLE_T2V

    ensure_dirs()
    ffmpeg = require_ffmpeg()

    # Startup: LTX Desktop required for idle + T2V paths
    ltx_ok = ltx_installed()
    if not ltx_ok:
        ENABLE_LTX_IDLE = False
        ENABLE_T2V = False
        print(
            "*** LTX Desktop not found — disabling idle auto-gen AND T2V queue. "
            "Main ComfyUI hive jobs only. ***"
        )

    print(f"Polling {PROCESS_URL}")
    print(f"T2V process {T2V_PROCESS_URL}")
    print(f"T2V upload  {T2V_UPLOAD_URL}")
    print(f"ComfyUI URL {COMFY_URL}")
    print(f"Autos dir   {AUTOS_DIR.resolve()}")
    print(
        f"FLAGS: MAX_SECONDS={MAX_SECONDS} ACCEPT_AUDIO={ACCEPT_AUDIO} "
        f"CLIENT_VERSION={CLIENT_VERSION}"
    )
    print(f"WORKER_ID: {WORKER_ID or '(none — set WORKER_ID for contact)'}")
    print(f"NCZ_ADDRESS: {NCZ_ADDRESS or '(none — set NCZ_ADDRESS for payouts)'}")
    print(f"Complete URL: {COMPLETE_URL}")
    print(f"Upload URL: {UPLOAD_URL}")
    print(f"Chunk size: {CHUNK_SIZE} | retries/chunk: {CHUNK_RETRIES}")
    print(
        f"LTX installed: {'YES' if ltx_ok else 'NO'} | "
        f"LTX idle: {'ON' if ENABLE_LTX_IDLE else 'OFF'} | "
        f"T2V: {'ON' if ENABLE_T2V else 'OFF'} | "
        f"idle defaults {LTX_RESOLUTION}×{LTX_DURATION}s | "
        f"POLL_DURING_GEN={POLL_DURING_GEN}s"
    )
    print(
        f"Prompt banks: scenes={len(SCENE_VARIANTS)} styles={len(STYLE_VARIANTS)} "
        f"refs={len(REFERENCE_VARIANTS)} items={len(ADDITIONAL_ITEMS)} babel={len(BABEL_TOPICS)}"
    )
    print("Startup scan for pending finals …")
    postprocess_pending(ffmpeg)

    while True:
        # 1) ALWAYS upscale/upload/complete before anything else
        postprocess_pending(ffmpeg)

        if list_pending_finals():
            print("Still have pending finals — not starting LTX, retry soon")
            time.sleep(15)
            continue

        # 2) Local zip → worker owns GPU; kill LTX
        zips = local_zips()
        if zips:
            if ltx_alive() or (_ltx_proc is not None and _ltx_proc.poll() is None):
                stop_ltx()
            print(
                f"Queue has {len(zips)} zip(s) — not contacting server. Sleep {BUSY_WAIT}s …"
            )
            time.sleep(BUSY_WAIT)
            continue

        # 3) Claim from MAIN hive — only if ComfyUI is up
        if not comfyui_alive():
            print(
                f"ComfyUI is down ({COMFY_URL}) — not requesting MAIN hive jobs. "
                f"Start ComfyUI, then jobs can be claimed. Sleep {EMPTY_WAIT}s …"
            )
            # Still allow T2V / idle below (they use LTX, not Comfy)
        else:
            print("Queue empty + no pending uploads — requesting filtered job from server …")
            result = fetch_once()
            postprocess_pending(ffmpeg)

            if result == "saved":
                stop_ltx()
                continue
            if result == "race":
                time.sleep(3)
                continue
            if result == "upgrade":
                stop_ltx()
                print(f"Sleeping {UPGRADE_WAIT}s (waiting for script update) …")
                time.sleep(UPGRADE_WAIT)
                continue
            if result == "error":
                time.sleep(EMPTY_WAIT)
                continue

        # 4) Between idles: claim text2video (needs LTX install)
        if ENABLE_T2V:
            print("Checking T2V queue …")
            t2v = fetch_t2v_once()
            if isinstance(t2v, dict):
                try:
                    ok = run_t2v_job(t2v, ffmpeg)
                    print(f"T2V job result ok={ok}")
                    if not ok:
                        print(f"T2V generate failed — sleep {UPLOAD_FAIL_WAIT}s before next claim")
                        time.sleep(UPLOAD_FAIL_WAIT)
                except Exception as e:
                    print(f"T2V job error: {e!r}")
                    print(f"T2V exception — sleep {UPLOAD_FAIL_WAIT}s before next claim")
                    time.sleep(UPLOAD_FAIL_WAIT)
                continue  # re-check main hive / uploads before idle
            if t2v == "race":
                time.sleep(2)
                continue
            if t2v == "upgrade":
                print(f"T2V protocol upgrade — sleep {UPGRADE_WAIT}s")
                time.sleep(UPGRADE_WAIT)
                continue
            # empty / error → fall through to idle

        # 5) Truly idle → random LTX (interruptible by MAIN hive zips only)
        if not ENABLE_LTX_IDLE:
            print(f"No job — LTX idle disabled. Sleep {EMPTY_WAIT}s …")
            time.sleep(EMPTY_WAIT)
            continue

        try:
            start_ltx()
            gen_result = ltx_generate_while_polling()
        except Exception as e:
            print(f"LTX idle cycle error: {e!r}")
            stop_ltx()
            time.sleep(5)
            continue

        if gen_result == "saved":
            continue
        if gen_result == "upgrade":
            print(f"Sleeping {UPGRADE_WAIT}s (waiting for script update) …")
            time.sleep(UPGRADE_WAIT)
            continue

        # next loop: postprocess → main claim → T2V claim → idle again
if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nStopped.")
        try:
            stop_ltx()
        except Exception:
            pass
        sys.exit(0)
